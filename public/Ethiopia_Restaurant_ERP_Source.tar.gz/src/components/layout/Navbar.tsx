import React from 'react';
import {
  LayoutDashboard,
  Warehouse,
  ClipboardList,
  GitBranch,
  ChefHat,
  CalendarDays,
  Scale,
  TrendingUp,
  PlusCircle,
  ArrowRightLeft,
  Calendar,
  Sparkles,
  Trash2,
  Database,
  HardDrive,
  Download,
  Users,
  UtensilsCrossed,
  ShieldCheck,
  CookingPot,
} from 'lucide-react';
import { useLanguage } from '../../context/LanguageContext';
import { useApp } from '../../context/AppContext';
import { formatEthiopianDate, getTodayDateString } from '../../utils/ethiopianDate';

export type ActiveTab =
  | 'dashboard'
  | 'centralStore'
  | 'binCard'
  | 'branchLedgers'
  | 'recipes'
  | 'staffMeals'
  | 'reconciliation'
  | 'fbReport'
  | 'priceTracking'
  | 'dataVault';

interface NavbarProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  onOpenStockIn: () => void;
  onOpenTransfer: () => void;
  onOpenDesktopInstall: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  onOpenStockIn,
  onOpenTransfer,
  onOpenDesktopInstall,
}) => {
  const { language, setLanguage, t } = useLanguage();
  const { clearAllDataCompletely, exportFullBackup, items, centralBinCards } = useApp();
  const todayStr = getTodayDateString();
  const ethDate = formatEthiopianDate(todayStr, language);

  const navItems = [
    { id: 'dashboard', label: t.nav.dashboard, icon: LayoutDashboard },
    { id: 'centralStore', label: t.nav.centralStore, icon: Warehouse },
    { id: 'binCard', label: t.nav.binCard, icon: ClipboardList },
    { id: 'branchLedgers', label: t.nav.branchLedgers, icon: GitBranch },
    { id: 'recipes', label: t.nav.recipes, icon: ChefHat },
    { id: 'staffMeals', label: t.nav.staffMeals, icon: Users, highlight: true },
    { id: 'reconciliation', label: t.nav.reconciliation, icon: Scale },
    { id: 'fbReport', label: t.nav.fbReport, icon: ShieldCheck, highlight: true },
    { id: 'priceTracking', label: t.nav.priceTracking, icon: TrendingUp },
    { id: 'dataVault', label: t.nav.dataVault, icon: Database, isGold: true },
  ];

  const handleWipeData = () => {
    if (window.confirm(language === 'am' ? 'ሙሉ ዳታዎችን አጽድተህ እንደ አዲስ ባዶ ማድረግ ትፈልጋለህ?' : 'Do you want to clear all data completely to a fresh blank start?')) {
      clearAllDataCompletely();
    }
  };

  return (
    <header className="sticky top-0 z-40 bg-slate-950/95 backdrop-blur-xl border-b border-amber-500/20 shadow-2xl">
      {/* Top Luxury Banner with Ethiopian Date Ticker & Golden Accents */}
      <div className="px-4 sm:px-6 py-2.5 flex flex-wrap items-center justify-between gap-3 text-xs border-b border-slate-800/80 bg-gradient-to-r from-slate-950 via-slate-900 to-amber-950/20">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 cursor-pointer" onClick={() => setActiveTab('dashboard')}>
            <span className="relative flex h-2.5 w-2.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-amber-400 shadow-sm shadow-amber-400"></span>
            </span>
            <span className="font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-amber-300 via-yellow-200 to-amber-500 tracking-wide text-xs sm:text-sm drop-shadow-sm">
              ETHIOPIA STORE & RECIPE ERP
            </span>
          </div>

          <span className="hidden lg:inline text-amber-500/30">|</span>

          {/* Ethiopian Calendar Badge with Gold Trim */}
          <div className="flex items-center gap-2 bg-gradient-to-r from-slate-900 via-amber-950/30 to-slate-900 px-3 py-1 rounded-xl border border-amber-500/30 shadow-inner">
            <Calendar className="w-3.5 h-3.5 text-amber-400" />
            <span className="text-amber-300 font-bold tracking-tight">🇪🇹 {ethDate}</span>
            <span className="text-slate-400 text-[11px] font-mono">({todayStr})</span>
          </div>
        </div>

        {/* Luxury Action Buttons & Toggles */}
        <div className="flex items-center gap-2.5 ml-auto">
          {/* Storage Center Gold Badge */}
          <button
            onClick={() => setActiveTab('dataVault')}
            title={language === 'am' ? 'የዳታ ማከማቻ ማዕከል' : 'Data Vault & Storage Center'}
            className={`relative group overflow-hidden flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-bold text-xs transition-all duration-200 border ${
              activeTab === 'dataVault'
                ? 'bg-gradient-to-r from-amber-400 to-yellow-500 text-slate-950 border-amber-300 shadow-md shadow-amber-500/30 font-black'
                : 'bg-slate-900/90 text-amber-300 border-amber-500/40 hover:border-amber-400 hover:bg-slate-850 shadow-sm'
            }`}
          >
            <Database className="w-3.5 h-3.5 text-amber-400 group-hover:scale-110 transition-transform" />
            <span className="hidden md:inline">{language === 'am' ? 'ዳታ ስቶሬጅ' : 'Data Vault'}</span>
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
          </button>

          {/* 1-Click Quick JSON Backup */}
          <button
            onClick={exportFullBackup}
            title={language === 'am' ? 'ፈጣን የዳታ ባክአፕ (.json) አውርድ' : 'Quick JSON Backup Download'}
            className="hidden sm:flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl font-bold text-xs text-amber-200 bg-amber-950/40 border border-amber-500/30 hover:bg-amber-900/60 transition-all"
          >
            <Download className="w-3 h-3 text-amber-400" />
            <span className="text-[11px]">{language === 'am' ? 'ባክአፕ' : 'Backup'}</span>
          </button>

          {/* Luxury Stock In Button */}
          <button
            onClick={onOpenStockIn}
            className="relative group overflow-hidden flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl font-bold text-xs text-white bg-gradient-to-r from-emerald-600 via-emerald-500 to-teal-600 shadow-md shadow-emerald-950/50 hover:shadow-emerald-500/25 hover:-translate-y-0.5 active:translate-y-0 transition-all duration-200 ring-1 ring-emerald-400/40"
          >
            <PlusCircle className="w-3.5 h-3.5" />
            <span>{t.dashboard.stockInBtn}</span>
          </button>

          {/* Luxury Transfer Button */}
          <button
            onClick={onOpenTransfer}
            className="relative group overflow-hidden flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl font-bold text-xs text-white bg-gradient-to-r from-blue-600 via-indigo-600 to-cyan-600 shadow-md shadow-blue-950/50 hover:shadow-blue-500/25 hover:-translate-y-0.5 active:translate-y-0 transition-all duration-200 ring-1 ring-blue-400/40"
          >
            <ArrowRightLeft className="w-3.5 h-3.5" />
            <span>{t.dashboard.transferBtn}</span>
          </button>

          {/* Mobile & Laptop App Install Button */}
          <button
            onClick={onOpenDesktopInstall}
            title={language === 'am' ? 'መተግበሪያውን ስልክዎ ወይም ላፕቶፕዎ ላይ ይጫኑ' : 'Install app on your phone or laptop'}
            className="relative group overflow-hidden flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-bold text-xs text-amber-300 bg-gradient-to-r from-amber-950/50 via-slate-900 to-amber-950/40 border border-amber-500/50 hover:border-amber-400 hover:bg-slate-850 shadow-md shadow-amber-950/30 transition-all duration-200"
          >
            <span className="text-sm">📲</span>
            <span className="font-extrabold">{language === 'am' ? 'ስልክ/ላፕቶፕ ላይ ጫን' : 'Install App'}</span>
          </button>

          {/* Bilingual Switcher with luxury tactile feel */}
          <div className="flex items-center bg-slate-900/90 rounded-xl p-0.5 border border-amber-500/20 shadow-inner">
            <button
              onClick={() => setLanguage('am')}
              className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all ${
                language === 'am'
                  ? 'bg-gradient-to-r from-amber-400 to-yellow-500 text-slate-950 shadow-sm shadow-amber-500/30 font-black'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              አማርኛ 🇪🇹
            </button>
            <button
              onClick={() => setLanguage('en')}
              className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all ${
                language === 'en'
                  ? 'bg-gradient-to-r from-amber-400 to-yellow-500 text-slate-950 shadow-sm shadow-amber-500/30 font-black'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              English 🌐
            </button>
          </div>

          {/* Clean Slate Wipe Button */}
          <button
            onClick={handleWipeData}
            title={language === 'am' ? 'ሙሉ ዳታ አጽዳ (Reset / Blank)' : 'Clear All Data (Clean Slate)'}
            className="p-1.5 text-slate-500 hover:text-rose-400 rounded-lg hover:bg-slate-900 transition-colors"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Main Luxury Navigation Bar */}
      <div className="px-4 sm:px-6">
        <div className="flex items-center justify-between h-13 overflow-x-auto no-scrollbar">
          <nav className="flex items-center gap-1 sm:gap-2">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id as ActiveTab)}
                  className={`relative flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs sm:text-sm font-semibold whitespace-nowrap transition-all duration-200 ${
                    isActive
                      ? item.highlight || item.isGold
                        ? 'bg-gradient-to-r from-amber-400 via-yellow-300 to-amber-500 text-slate-950 shadow-lg shadow-amber-500/25 font-black ring-1 ring-amber-300/60'
                        : 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-lg shadow-emerald-500/20 font-bold ring-1 ring-emerald-400/40'
                      : item.highlight || item.isGold
                      ? 'text-amber-400 hover:bg-amber-950/30 hover:text-amber-300 border border-amber-500/30'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
                  }`}
                >
                  <Icon className="w-4 h-4 shrink-0" />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </nav>
        </div>
      </div>
    </header>
  );
};
