import { InventoryItem, Branch, CentralBinCardEntry, BranchLedgerEntry, Recipe, ProductionSchedule } from '../types';
import { getTodayDateString, getRelativeDateString, formatEthiopianDate } from '../utils/ethiopianDate';

// Default starting arrays are completely empty as requested by user ("አንተ ባዶ አድርገህ ነው የምትሰጠኝ")
export const INITIAL_BRANCHES: Branch[] = [];
export const INITIAL_ITEMS: InventoryItem[] = [];
export const INITIAL_CENTRAL_BIN_CARD: CentralBinCardEntry[] = [];
export const INITIAL_BRANCH_LEDGERS: BranchLedgerEntry[] = [];
export const INITIAL_RECIPES: Recipe[] = [];
export const INITIAL_SCHEDULES: ProductionSchedule[] = [];

// Optional Realistic Ethiopian Restaurant & Store Template
const today = getTodayDateString();
const yesterday = getRelativeDateString(-1);
const twoDaysAgo = getRelativeDateString(-2);

export const SAMPLE_BRANCHES: Branch[] = [
  {
    id: 'br-bole',
    code: 'BR-BOL-01',
    nameAm: 'ቦሌ ቅርንጫፍ',
    nameEn: 'Bole Branch',
    location: 'ቦሌ መድኃኔዓለም ፊት ለፊት',
    manager: 'አቶ ዳዊት ከበደ',
    phone: '+251 911 234 567',
  },
  {
    id: 'br-piassa',
    code: 'BR-PIA-02',
    nameAm: 'ፒያሳ ቅርንጫፍ',
    nameEn: 'Piassa Branch',
    location: 'ቸርችል ጎዳና፣ ቴዎድሮስ አደባባይ',
    manager: 'ወ/ሮ ትዕግስት ኃይሉ',
    phone: '+251 911 345 678',
  },
  {
    id: 'br-cmc',
    code: 'BR-CMC-03',
    nameAm: 'ሲኤምሲ ቅርንጫፍ',
    nameEn: 'CMC Branch',
    location: 'ሲኤምሲ ሚካኤል አደባባይ',
    manager: 'አቶ ዮናስ ታደሰ',
    phone: '+251 911 456 789',
  },
];

export const SAMPLE_ITEMS: InventoryItem[] = [
  {
    id: 'raw-teff',
    code: 'RM-TEF-01',
    nameAm: 'ነጭ ጤፍ (የማኛ)',
    nameEn: 'White Magna Teff',
    category: 'grain',
    unit: 'quintal',
    unitAm: 'ኩንታል',
    minStockLevel: 5,
    currentCentralStock: 45,
    weightedAvgCost: 9800,
    lastPurchasePrice: 10200,
    priceHistory: [
      {
        date: today,
        ethiopianDateStr: formatEthiopianDate(today),
        price: 10200,
        quantity: 20,
        supplier: 'አዳማ እህል ነጋዴዎች ህብረት',
        grnNumber: 'GRN-2026-0042',
      },
      {
        date: twoDaysAgo,
        ethiopianDateStr: formatEthiopianDate(twoDaysAgo),
        price: 9500,
        quantity: 30,
        supplier: 'ደብረዘይት አርሶ አደሮች',
        grnNumber: 'GRN-2026-0021',
      },
    ],
  },
  {
    id: 'raw-beef',
    code: 'RM-BEEF-01',
    nameAm: 'የበሬ ስጋ (ልዩ ፍርምባና ቋንጣ)',
    nameEn: 'Fresh Beef Special',
    category: 'meat',
    unit: 'kg',
    unitAm: 'ኪ.ግ',
    minStockLevel: 50,
    currentCentralStock: 180,
    weightedAvgCost: 850,
    lastPurchasePrice: 880,
    priceHistory: [
      {
        date: today,
        ethiopianDateStr: formatEthiopianDate(today),
        price: 880,
        quantity: 100,
        supplier: 'ቃሊቲ ቄራዎች ድርጅት',
        grnNumber: 'GRN-2026-0045',
      },
    ],
  },
  {
    id: 'raw-onion',
    code: 'RM-ONION-01',
    nameAm: 'ቀይ ሽንኩርት (ሀበሻ)',
    nameEn: 'Red Onions (Local)',
    category: 'produce',
    unit: 'kg',
    unitAm: 'ኪ.ግ',
    minStockLevel: 100,
    currentCentralStock: 320,
    weightedAvgCost: 110,
    lastPurchasePrice: 125,
    priceHistory: [
      {
        date: today,
        ethiopianDateStr: formatEthiopianDate(today),
        price: 125,
        quantity: 200,
        supplier: 'መቂ ሻሸመኔ አትክልት ተረካቢ',
        grnNumber: 'GRN-2026-0046',
      },
    ],
  },
  {
    id: 'raw-berbere',
    code: 'RM-BERB-01',
    nameAm: 'ልዩ የባህል በርበሬ',
    nameEn: 'Traditional Berbere Spice',
    category: 'spices',
    unit: 'kg',
    unitAm: 'ኪ.ግ',
    minStockLevel: 25,
    currentCentralStock: 65,
    weightedAvgCost: 450,
    lastPurchasePrice: 480,
    priceHistory: [
      {
        date: yesterday,
        ethiopianDateStr: formatEthiopianDate(yesterday),
        price: 480,
        quantity: 40,
        supplier: 'መርካቶ የቅመማ ቅመም ማዕከል',
        grnNumber: 'GRN-2026-0038',
      },
    ],
  },
  {
    id: 'raw-oil',
    code: 'RM-OIL-01',
    nameAm: 'የምግብ ዘይት (20 ሊትር ጄሪካን)',
    nameEn: 'Cooking Oil (20L Jerrycan)',
    category: 'oil',
    unit: 'bottle',
    unitAm: 'ጄሪካን (20L)',
    minStockLevel: 10,
    currentCentralStock: 28,
    weightedAvgCost: 3400,
    lastPurchasePrice: 3550,
    priceHistory: [
      {
        date: twoDaysAgo,
        ethiopianDateStr: formatEthiopianDate(twoDaysAgo),
        price: 3550,
        quantity: 15,
        supplier: 'ዋፍ የምግብ ዘይት ፋብሪካ',
        grnNumber: 'GRN-2026-0029',
      },
    ],
  },
  {
    id: 'raw-butter',
    code: 'RM-BUTT-01',
    nameAm: 'የሸኖ ንጥር ቅቤ',
    nameEn: 'Sheno Spiced Clarified Butter',
    category: 'dairy',
    unit: 'kg',
    unitAm: 'ኪ.ግ',
    minStockLevel: 15,
    currentCentralStock: 35,
    weightedAvgCost: 1250,
    lastPurchasePrice: 1300,
    priceHistory: [
      {
        date: yesterday,
        ethiopianDateStr: formatEthiopianDate(yesterday),
        price: 1300,
        quantity: 20,
        supplier: 'ሸኖ የወተት እና ቅቤ ህብረት',
        grnNumber: 'GRN-2026-0036',
      },
    ],
  },
];

export const SAMPLE_RECIPES: Recipe[] = [
  {
    id: 'rec-tibs',
    branchId: 'br-bole',
    nameAm: 'ልዩ የበሬ ጥብስ (ከነማባያው)',
    nameEn: 'Special Beef Tibs',
    category: 'ዋና ምግብ (Main Dish)',
    portionDescription: '1 ፖርሽን ከእንጀራ እና ሰላጣ ጋር',
    sellingPrice: 550,
    ingredients: [
      { itemId: 'raw-beef', quantity: 0.35 },
      { itemId: 'raw-onion', quantity: 0.15 },
      { itemId: 'raw-oil', quantity: 0.003 },
      { itemId: 'raw-butter', quantity: 0.04 },
      { itemId: 'raw-berbere', quantity: 0.02 },
    ],
    isActive: true,
  },
  {
    id: 'rec-shiro',
    branchId: 'br-bole',
    nameAm: 'ተጋቢኖ ሽሮ በቅቤ',
    nameEn: 'Tegabino Shiro with Butter',
    category: 'ዋና ምግብ (Main Dish)',
    portionDescription: 'በሸክላ ድስት የሚንተከተክ',
    sellingPrice: 280,
    ingredients: [
      { itemId: 'raw-onion', quantity: 0.12 },
      { itemId: 'raw-berbere', quantity: 0.03 },
      { itemId: 'raw-butter', quantity: 0.05 },
      { itemId: 'raw-oil', quantity: 0.002 },
    ],
    isActive: true,
  },
];
