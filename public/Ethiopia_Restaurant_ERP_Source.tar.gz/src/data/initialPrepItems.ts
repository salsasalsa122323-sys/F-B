import { KitchenPrepItem } from '../types';

export const INITIAL_PREP_ITEMS: KitchenPrepItem[] = [
  {
    id: 'prep-bolognese',
    nameAm: 'ቦሎኛይስ ሶስ (Bolognese Sauce)',
    nameEn: 'Bolognese Sauce',
    category: 'sauce',
    outputUnit: 'kg',
    outputUnitAm: 'ኪ.ግ',
    batchYield: 1, // per 1 kg of prepared sauce
    ingredients: [
      { itemId: 'raw-beef', quantity: 0.5 }, // 500g minced beef per 1kg sauce
      { itemId: 'raw-onion', quantity: 0.15 }, // 150g onion
      { itemId: 'raw-oil', quantity: 0.05 }, // oil
    ],
    preparationNotes: 'ለስፓጌቲ ቦሎኛይስ፣ ላዛኛ እና ፌቱቺኒ የሚሆን ማዕከላዊ የሶስ ዝግጅት',
    isActive: true,
  },
  {
    id: 'prep-pesto',
    nameAm: 'ፔስቶ ሶስ (Pesto Sauce)',
    nameEn: 'Pesto Sauce',
    category: 'sauce',
    outputUnit: 'kg',
    outputUnitAm: 'ኪ.ግ',
    batchYield: 1,
    ingredients: [
      { itemId: 'raw-oil', quantity: 0.3 },
      { itemId: 'raw-onion', quantity: 0.1 },
    ],
    preparationNotes: 'በባሲል ቅጠል፣ በነጭ ሽንኩርትና በወይራ ዘይት የተዘጋጀ የጣሊያን ፔስቶ',
    isActive: true,
  },
  {
    id: 'prep-zafferano',
    nameAm: 'ዛፈራኖ ሶስ (Zafferano Cream Sauce)',
    nameEn: 'Zafferano Sauce',
    category: 'sauce',
    outputUnit: 'kg',
    outputUnitAm: 'ኪ.ግ',
    batchYield: 1,
    ingredients: [
      { itemId: 'raw-oil', quantity: 0.15 },
      { itemId: 'raw-onion', quantity: 0.1 },
    ],
    preparationNotes: 'የዛፈራኖ ክሬም ሶስ ለፓስታና ሪሶቶ',
    isActive: true,
  },
  {
    id: 'prep-tomato',
    nameAm: 'ቶማቶ ሶስ (Tomato Pomodoro Sauce)',
    nameEn: 'Tomato Pomodoro Sauce',
    category: 'sauce',
    outputUnit: 'kg',
    outputUnitAm: 'ኪ.ግ',
    batchYield: 1,
    ingredients: [
      { itemId: 'raw-onion', quantity: 0.2 },
      { itemId: 'raw-oil', quantity: 0.08 },
    ],
    preparationNotes: 'ለፒዛና ለተለያዩ የፓስታ አይነቶች መሰረት የሆነ የቲማቲም ሶስ',
    isActive: true,
  },
  {
    id: 'prep-burger-patty',
    nameAm: 'የበርገር ፓቲ (Burger Patty Prep)',
    nameEn: 'Burger Patty Prep',
    category: 'patty',
    outputUnit: 'pcs',
    outputUnitAm: 'ፍሬ',
    batchYield: 10, // per 10 patties
    ingredients: [
      { itemId: 'raw-beef', quantity: 1.3 }, // 1.3kg fresh beef per 10 patties (130g each)
      { itemId: 'raw-onion', quantity: 0.1 },
    ],
    preparationNotes: 'ለኮኮኑ እና ለጁስ ብራንች የሚዘጋጅ 130 ግራም ደረጃውን የጠበቀ የበርገር ፓቲ',
    isActive: true,
  },
  {
    id: 'prep-pizza-meat',
    nameAm: 'የፒዛ ስጋ ዝግጅት (Pizza Meat Seasoned)',
    nameEn: 'Pizza Meat Seasoned',
    category: 'meat_prep',
    outputUnit: 'kg',
    outputUnitAm: 'ኪ.ግ',
    batchYield: 1,
    ingredients: [
      { itemId: 'raw-beef', quantity: 1.05 }, // 1.05kg beef with trim loss
      { itemId: 'raw-oil', quantity: 0.05 },
    ],
    preparationNotes: 'የተቀመመና የተዘጋጀ የፒዛ ስጋ',
    isActive: true,
  },
  {
    id: 'prep-dressing',
    nameAm: 'የሰላጣ ድሬሲንግ (House Salad Dressing)',
    nameEn: 'House Salad Dressing',
    category: 'dressing',
    outputUnit: 'liter',
    outputUnitAm: 'ሊትር',
    batchYield: 1,
    ingredients: [
      { itemId: 'raw-oil', quantity: 0.4 },
      { itemId: 'raw-onion', quantity: 0.1 },
    ],
    preparationNotes: 'የቤት ውስጥ የሰላጣ ማጣፈጫ ድሬሲንግ',
    isActive: true,
  },
];
