import React, { useState } from 'react';
import {
  Warehouse,
  PlusCircle,
  ArrowRightLeft,
  Search,
  Filter,
  ClipboardList,
  AlertTriangle,
  TrendingUp,
  PackagePlus,
  Sparkles,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { useLanguage } from '../context/LanguageContext';
import { ItemCategory } from '../types';

interface CentralStoreViewProps {
  onOpenStockIn: (itemId?: string) => void;
  onOpenTransfer: (itemId?: string) => void;
  onSelectBinCardItem: (itemId: string) => void;
  onOpenNewItem: () => void;
}

export const CentralStoreView: React.FC<CentralStoreViewProps> = ({
  onOpenStockIn,
  onOpenTransfer,
  onSelectBinCardItem,
  onOpenNewItem,
}) => {
  const { items } = useApp();
  const { language, t, formatCurrency } = useLanguage();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  const filteredItems = items.filter((item) => {
    const matchesSearch =
      item.nameAm.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.nameEn.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.code.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesCategory = selectedCategory === 'all' || item.category === selectedCategory;

    return matchesSearch && matchesCategory;
  });

  const totalCentralVal = filteredItems.reduce(
    (sum, i) => sum + i.currentCentralStock * i.weightedAvgCost,
    0
  );

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Header & Luxury Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-white flex items-center gap-2.5">
            <Warehouse className="w-6 h-6 text-amber-400" />
            <span className="bg-gradient-to-r from-amber-200 via-amber-400 to-yellow-500 bg-clip-text text-transparent">
              {t.centralStore.title}
            </span>
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            {t.centralStore.subtitle}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            onClick={onOpenNewItem}
            className="flex items-center gap-1.5 px-3.5 py-2 bg-slate-900 border border-amber-500/40 hover:border-amber-400 hover:bg-slate-850 text-amber-300 rounded-xl text-xs font-bold shadow-md transition-all"
          >
            <PackagePlus className="w-4 h-4 text-amber-400" />
            <span>{t.centralStore.addNewItem}</span>
          </button>
          <button
            onClick={() => onOpenStockIn()}
            className="flex items-center gap-1.5 px-4 py-2 bg-gradient-to-r from-emerald-600 via-emerald-500 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white rounded-xl text-xs font-bold shadow-lg shadow-emerald-950/60 transition-all ring-1 ring-emerald-400/40"
          >
            <PlusCircle className="w-4 h-4" />
            <span>{t.centralStore.stockIn}</span>
          </button>
          <button
            onClick={() => onOpenTransfer()}
            className="flex items-center gap-1.5 px-4 py-2 bg-gradient-to-r from-blue-600 via-indigo-600 to-cyan-600 hover:from-blue-500 hover:to-cyan-500 text-white rounded-xl text-xs font-bold shadow-lg shadow-blue-950/60 transition-all ring-1 ring-blue-400/40"
          >
            <ArrowRightLeft className="w-4 h-4" />
            <span>{t.centralStore.stockOutTransfer}</span>
          </button>
        </div>
      </div>

      {/* Search & Category Filter Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-slate-900/80 p-4 rounded-2xl border border-amber-500/20 shadow-xl backdrop-blur-md">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-amber-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder={language === 'am' ? 'በስም ወይም በኮድ ፈልግ...' : 'Search raw materials...'}
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-400 transition-all"
          />
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto overflow-x-auto no-scrollbar">
          <Filter className="w-3.5 h-3.5 text-amber-400 shrink-0" />
          {['all', 'produce', 'meat', 'grain', 'oil', 'dairy', 'spices', 'beverage'].map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
                selectedCategory === cat
                  ? 'bg-gradient-to-r from-amber-400 to-yellow-500 text-slate-950 font-black shadow-md shadow-amber-500/25 ring-1 ring-amber-300/50'
                  : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-800'
              }`}
            >
              {cat === 'all'
                ? t.common.all
                : cat === 'produce'
                ? (language === 'am' ? 'አትክልት' : 'Produce')
                : cat === 'meat'
                ? (language === 'am' ? 'ስጋ' : 'Meat')
                : cat === 'grain'
                ? (language === 'am' ? 'እህል/ዱቄት' : 'Grain')
                : cat === 'oil'
                ? (language === 'am' ? 'ዘይት' : 'Oil')
                : cat === 'dairy'
                ? (language === 'am' ? 'ወተት/ቅቤ' : 'Dairy')
                : cat === 'spices'
                ? (language === 'am' ? 'ቅመማ ቅመም' : 'Spices')
                : (language === 'am' ? 'መጠጥ' : 'Beverage')}
            </button>
          ))}
        </div>
      </div>

      {/* Main Stock Table with Gold Trim */}
      <div className="bg-slate-900/80 rounded-3xl border border-amber-500/20 shadow-2xl overflow-hidden backdrop-blur-md">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-slate-950/90 border-b border-amber-500/20 text-slate-300 font-bold">
                <th className="py-3.5 px-4">{language === 'am' ? 'ኮድ' : 'Code'}</th>
                <th className="py-3.5 px-4">{t.common.item}</th>
                <th className="py-3.5 px-4">{t.common.unit}</th>
                <th className="py-3.5 px-4 text-right">{t.centralStore.currentStock}</th>
                <th className="py-3.5 px-4 text-right">{t.centralStore.avgCost}</th>
                <th className="py-3.5 px-4 text-right">{t.centralStore.lastPrice}</th>
                <th className="py-3.5 px-4 text-right">{t.common.totalPrice}</th>
                <th className="py-3.5 px-4 text-center">{t.common.status}</th>
                <th className="py-3.5 px-4 text-center">{t.common.actions}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 bg-slate-900/40">
              {filteredItems.length === 0 ? (
                <tr>
                  <td colSpan={9} className="py-12 text-center text-slate-400">
                    <div className="space-y-2">
                      <p>{language === 'am' ? 'እስካሁን ምንም ጥሬ ዕቃ አልተመዘገበም' : 'No items found'}</p>
                      <button
                        onClick={onOpenNewItem}
                        className="text-xs text-amber-400 hover:text-amber-300 font-bold underline"
                      >
                        + {t.centralStore.addNewItem}
                      </button>
                    </div>
                  </td>
                </tr>
              ) : (
                filteredItems.map((item) => {
                  const isLow = item.currentCentralStock <= item.minStockLevel;
                  const totalVal = item.currentCentralStock * item.weightedAvgCost;
                  const priceDiff = item.lastPurchasePrice - item.weightedAvgCost;
                  const priceDiffPct = item.weightedAvgCost > 0 ? (priceDiff / item.weightedAvgCost) * 100 : 0;

                  return (
                    <tr
                      key={item.id}
                      className="hover:bg-amber-500/[0.04] transition-colors"
                    >
                      <td className="py-3.5 px-4 font-mono text-[11px] text-amber-300 font-semibold">
                        {item.code}
                      </td>
                      <td className="py-3.5 px-4">
                        <div className="font-bold text-white">
                          {language === 'am' ? item.nameAm : item.nameEn}
                        </div>
                        <div className="text-[11px] text-slate-400">
                          {language === 'am' ? item.nameEn : item.nameAm}
                        </div>
                      </td>
                      <td className="py-3.5 px-4 text-slate-300">
                        {item.unitAm} ({item.unit})
                      </td>
                      <td className="py-3.5 px-4 text-right font-black text-white">
                        {item.currentCentralStock.toLocaleString()} {item.unitAm}
                      </td>
                      <td className="py-3.5 px-4 text-right font-medium text-slate-300">
                        {formatCurrency(item.weightedAvgCost)}
                      </td>
                      <td className="py-3.5 px-4 text-right">
                        <span className="font-bold text-amber-300 block">
                          {formatCurrency(item.lastPurchasePrice)}
                        </span>
                        {priceDiff !== 0 && (
                          <span
                            className={`text-[10px] font-bold ${
                              priceDiff > 0 ? 'text-rose-400' : 'text-emerald-400'
                            }`}
                          >
                            {priceDiff > 0 ? `+${priceDiffPct.toFixed(1)}%` : `${priceDiffPct.toFixed(1)}%`}
                          </span>
                        )}
                      </td>
                      <td className="py-3.5 px-4 text-right font-black text-amber-300">
                        {formatCurrency(totalVal)}
                      </td>
                      <td className="py-3.5 px-4 text-center">
                        {isLow ? (
                          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-rose-950 text-rose-300 border border-rose-800/50">
                            <AlertTriangle className="w-3 h-3" />
                            <span>{language === 'am' ? 'አነስተኛ' : 'Low Stock'}</span>
                          </span>
                        ) : (
                          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-950 text-emerald-300 border border-emerald-800/50">
                            {language === 'am' ? 'በቂ ነው' : 'In Stock'}
                          </span>
                        )}
                      </td>
                      <td className="py-3.5 px-4 text-center">
                        <div className="flex items-center justify-center gap-1">
                          <button
                            onClick={() => onSelectBinCardItem(item.id)}
                            title={t.centralStore.viewBinCard}
                            className="p-1.5 text-slate-400 hover:text-amber-300 rounded-lg hover:bg-slate-800 transition-colors"
                          >
                            <ClipboardList className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => onOpenStockIn(item.id)}
                            title={t.centralStore.stockIn}
                            className="p-1.5 text-slate-400 hover:text-emerald-400 rounded-lg hover:bg-slate-800 transition-colors"
                          >
                            <PlusCircle className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => onOpenTransfer(item.id)}
                            title={t.centralStore.stockOutTransfer}
                            className="p-1.5 text-slate-400 hover:text-blue-400 rounded-lg hover:bg-slate-800 transition-colors"
                          >
                            <ArrowRightLeft className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Table Footer */}
        <div className="px-6 py-4 bg-slate-950/80 border-t border-amber-500/20 flex flex-col sm:flex-row items-center justify-between gap-2 text-xs text-slate-400">
          <span>
            {language === 'am' ? 'የተገኙ እቃዎች ብዛት:' : 'Items shown:'} <strong className="text-white">{filteredItems.length}</strong>
          </span>
          <span>
            {language === 'am' ? 'የተጣራ አጠቃላይ የማዕከላዊ ዋጋ:' : 'Filtered Total Value:'}{' '}
            <strong className="text-amber-300 font-black text-sm">
              {formatCurrency(totalCentralVal)}
            </strong>
          </span>
        </div>
      </div>
    </div>
  );
};
