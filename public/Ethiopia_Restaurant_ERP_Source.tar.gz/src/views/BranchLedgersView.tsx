import React, { useState } from 'react';
import {
  GitBranch,
  Building2,
  PlusCircle,
  ArrowRightLeft,
  Flame,
  Printer,
  Download,
  Calendar,
  Filter,
  CheckCircle,
  AlertCircle,
  User,
  Phone,
  MapPin,
  TrendingDown,
  Sparkles,
  DollarSign,
  Briefcase,
  Users,
  Layers,
  FileSpreadsheet,
  CheckCircle2,
  AlertTriangle,
  History,
  Lock,
  RotateCcw,
  Receipt,
  X,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { useLanguage } from '../context/LanguageContext';
import { DatePickerField } from '../components/common/DatePickerField';
import { formatEthiopianDate, getRelativeDateString, getTodayDateString } from '../utils/ethiopianDate';
import { BranchDailyClosing, BranchDailyClosingItemSummary } from '../types';

interface BranchLedgersViewProps {
  onOpenTransfer: (itemId?: string, branchId?: string) => void;
  onOpenBranchUsage: (branchId: string) => void;
  onOpenNewBranch: () => void;
}

export const BranchLedgersView: React.FC<BranchLedgersViewProps> = ({
  onOpenTransfer,
  onOpenBranchUsage,
  onOpenNewBranch,
}) => {
  const {
    branches,
    items,
    branchLedgers,
    getBranchStockBalance,
    setBeginningStock,
    branchDailyClosings,
    closeBranchDailyAccount,
    createDefaultThreeBranches,
  } = useApp();
  const { language, t, formatCurrency } = useLanguage();

  const [selectedBranchId, setSelectedBranchId] = useState<string>(
    branches[0]?.id || ''
  );

  const [selectedTab, setSelectedTab] = useState<'balance' | 'closing' | 'ledger' | 'pastClosings'>('balance');
  const [filterItemId, setFilterItemId] = useState<string>('ALL');
  const [filterType, setFilterType] = useState<string>('ALL');

  // Ledger Date filters
  const [startDate, setStartDate] = useState(getRelativeDateString(-30));
  const [endDate, setEndDate] = useState(getTodayDateString());

  // Closing Report Date
  const [closingDate, setClosingDate] = useState(getTodayDateString());
  const [closingPhysicalCounts, setClosingPhysicalCounts] = useState<Record<string, number>>({});
  const [closingNotes, setClosingNotes] = useState('');
  const [closingSuccessMsg, setClosingSuccessMsg] = useState(false);

  // Beginning Inventory Modal state
  const [beginningModalOpen, setBeginningModalOpen] = useState(false);
  const [beginningItemId, setBeginningItemId] = useState(items[0]?.id || '');
  const [beginningQty, setBeginningQty] = useState<number | ''>('');
  const [beginningCost, setBeginningCost] = useState<number | ''>('');
  const [beginningDate, setBeginningDate] = useState(getTodayDateString());
  const [beginningSuccess, setBeginningSuccess] = useState(false);

  const currentBranch = branches.find((b) => b.id === selectedBranchId) || branches[0];

  // Ledger entries filtered by branch, date, item, and type
  const filteredLedgerEntries = branchLedgers
    .filter((entry) => entry.branchId === (currentBranch?.id || ''))
    .filter((entry) => {
      const isAfterStart = !startDate || entry.date >= startDate;
      const isBeforeEnd = !endDate || entry.date <= endDate;
      const matchesItem = filterItemId === 'ALL' || entry.itemId === filterItemId;
      const matchesType = filterType === 'ALL' || entry.type === filterType;
      return isAfterStart && isBeforeEnd && matchesItem && matchesType;
    })
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  // Current stock balances for this branch with breakdown
  const branchStockItems = items.map((it) => {
    const bal = currentBranch ? getBranchStockBalance(currentBranch.id, it.id) : 0;
    const totalVal = bal * (it.weightedAvgCost || it.lastPurchasePrice || 0);

    // Compute all historical inputs and outputs for this branch
    const itemEntries = branchLedgers.filter(
      (e) => e.branchId === (currentBranch?.id || '') && e.itemId === it.id
    );

    let beginningStock = 0;
    let totalSivIn = 0;
    let cashSalesOut = 0;
    let managementOut = 0;
    let staffMealOut = 0;
    let wasteOut = 0;

    itemEntries.forEach((e) => {
      if (e.type === 'BEGINNING_STOCK') beginningStock += e.quantityIn || 0;
      else if (e.type === 'TRANSFER_IN') totalSivIn += e.quantityIn || 0;
      else if (e.type === 'CASH_SALE' || e.type === 'DIRECT_SALE') cashSalesOut += e.quantityOut || 0;
      else if (e.type === 'MANAGEMENT_USE') managementOut += e.quantityOut || 0;
      else if (e.type === 'STAFF_MEAL') staffMealOut += e.quantityOut || 0;
      else if (e.type === 'WASTE_DAMAGE') wasteOut += e.quantityOut || 0;
      else if (e.type === 'KITCHEN_USAGE') staffMealOut += e.quantityOut || 0;
    });

    return {
      ...it,
      branchBalance: bal,
      totalVal,
      beginningStock,
      totalSivIn,
      cashSalesOut,
      managementOut,
      staffMealOut,
      wasteOut,
    };
  });

  const totalBranchValue = branchStockItems.reduce((sum, i) => sum + i.totalVal, 0);

  // Compute Daily Closing Breakdown for Selected Closing Date
  const dailyLedgerEntries = branchLedgers.filter(
    (e) => e.branchId === (currentBranch?.id || '') && e.date === closingDate
  );

  let totalDayCashRevenue = 0;
  let totalDayManagementCost = 0;
  let totalDayStaffMealCost = 0;
  let totalDayMaterialCost = 0;

  const dailyClosingItemSummaries: BranchDailyClosingItemSummary[] = items.map((it) => {
    const unitCost = it.weightedAvgCost || it.lastPurchasePrice || 0;

    // Beginning stock as of start of this day
    const priorEntries = branchLedgers.filter(
      (e) => e.branchId === (currentBranch?.id || '') && e.itemId === it.id && e.date < closingDate
    );
    let beginningStock = 0;
    priorEntries.forEach((e) => {
      beginningStock += (e.quantityIn || 0) - (e.quantityOut || 0);
    });
    // Check if there was an explicit beginning stock logged on this day
    const begOnDay = dailyLedgerEntries.find(
      (e) => e.itemId === it.id && e.type === 'BEGINNING_STOCK'
    );
    if (begOnDay) beginningStock += begOnDay.quantityIn || 0;
    beginningStock = Math.max(0, Number(beginningStock.toFixed(3)));

    let receivedSIV = 0;
    let cashSaleQty = 0;
    let managementQty = 0;
    let staffMealQty = 0;
    let damageQty = 0;

    dailyLedgerEntries
      .filter((e) => e.itemId === it.id)
      .forEach((e) => {
        if (e.type === 'TRANSFER_IN') receivedSIV += e.quantityIn || 0;
        else if (e.type === 'CASH_SALE' || e.type === 'DIRECT_SALE') {
          cashSaleQty += e.quantityOut || 0;
          totalDayCashRevenue += e.cashRevenue || 0;
          totalDayMaterialCost += e.totalValue || (e.quantityOut * unitCost);
        } else if (e.type === 'MANAGEMENT_USE') {
          managementQty += e.quantityOut || 0;
          totalDayManagementCost += e.totalValue || (e.quantityOut * unitCost);
          totalDayMaterialCost += e.totalValue || (e.quantityOut * unitCost);
        } else if (e.type === 'STAFF_MEAL' || e.type === 'KITCHEN_USAGE') {
          staffMealQty += e.quantityOut || 0;
          totalDayStaffMealCost += e.totalValue || (e.quantityOut * unitCost);
          totalDayMaterialCost += e.totalValue || (e.quantityOut * unitCost);
        } else if (e.type === 'WASTE_DAMAGE') {
          damageQty += e.quantityOut || 0;
          totalDayMaterialCost += e.totalValue || (e.quantityOut * unitCost);
        }
      });

    receivedSIV = Number(receivedSIV.toFixed(3));
    cashSaleQty = Number(cashSaleQty.toFixed(3));
    managementQty = Number(managementQty.toFixed(3));
    staffMealQty = Number(staffMealQty.toFixed(3));
    damageQty = Number(damageQty.toFixed(3));

    const totalOutQty = Number((cashSaleQty + managementQty + staffMealQty + damageQty).toFixed(3));
    const expectedClosingStock = Math.max(0, Number((beginningStock + receivedSIV - totalOutQty).toFixed(3)));

    // Actual physical count entered by user
    const actualPhysicalStock = closingPhysicalCounts[it.id] !== undefined
      ? closingPhysicalCounts[it.id]
      : expectedClosingStock;

    const varianceQty = Number((actualPhysicalStock - expectedClosingStock).toFixed(3));
    const varianceCostETB = Number((varianceQty * unitCost).toFixed(2));

    let status: 'balanced' | 'shortage' | 'excess' = 'balanced';
    if (varianceQty < 0) status = 'shortage';
    else if (varianceQty > 0) status = 'excess';

    return {
      itemId: it.id,
      itemNameAm: it.nameAm,
      itemNameEn: it.nameEn,
      unitAm: it.unitAm,
      unitCost,
      beginningStock,
      receivedSIV,
      cashSaleQty,
      managementQty,
      staffMealQty,
      damageQty,
      totalOutQty,
      expectedClosingStock,
      actualPhysicalStock,
      varianceQty,
      varianceCostETB,
      status,
    };
  });

  const totalVarianceCost = dailyClosingItemSummaries.reduce((sum, i) => sum + i.varianceCostETB, 0);

  // Check if today already has a closed settlement record
  const existingDayClosing = branchDailyClosings.find(
    (c) => c.branchId === (currentBranch?.id || '') && c.date === closingDate
  );

  // Handle Close Day Account & Lock
  const handleFinalizeDailyClosing = () => {
    if (!currentBranch) return;

    const closingPayload: BranchDailyClosing = {
      id: `close-${currentBranch.id}-${closingDate}`,
      branchId: currentBranch.id,
      date: closingDate,
      ethiopianDateStr: formatEthiopianDate(closingDate),
      closingNumber: `CLS-${currentBranch.code}-${closingDate.replace(/-/g, '')}`,
      closedBy: currentBranch.manager || 'የቅርንጫፍ አስተዳዳሪ',
      closedAt: new Date().toISOString(),
      totalCashSalesETB: Number(totalDayCashRevenue.toFixed(2)),
      totalManagementCostETB: Number(totalDayManagementCost.toFixed(2)),
      totalStaffMealCostETB: Number(totalDayStaffMealCost.toFixed(2)),
      totalMaterialCostETB: Number(totalDayMaterialCost.toFixed(2)),
      totalVarianceCostETB: Number(totalVarianceCost.toFixed(2)),
      itemSummaries: dailyClosingItemSummaries,
      notes: closingNotes,
      status: 'closed',
    };

    closeBranchDailyAccount(closingPayload);
    setClosingSuccessMsg(true);
    setTimeout(() => setClosingSuccessMsg(false), 2500);
  };

  // Handle Beginning Inventory Submission
  const handleSaveBeginningStock = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentBranch || !beginningItemId || beginningQty === '') return;

    const parsedQty = typeof beginningQty === 'number' ? beginningQty : 0;
    const parsedCost = typeof beginningCost === 'number' ? beginningCost : undefined;

    setBeginningStock(currentBranch.id, beginningItemId, parsedQty, beginningDate, parsedCost);
    setBeginningSuccess(true);
    setTimeout(() => {
      setBeginningSuccess(false);
      setBeginningModalOpen(false);
      setBeginningQty('');
    }, 800);
  };

  // Export Daily Closing Report to CSV
  const exportDailyClosingCSV = () => {
    if (!currentBranch) return;
    const headers = [
      'Item Code',
      'Item Name',
      'Unit',
      'Beginning Stock',
      'SIV Received',
      'Cash Sales Qty',
      'Management Use Qty',
      'Staff Meal Qty',
      'Damage Qty',
      'Total Dispatched',
      'Expected Closing Stock',
      'Actual Count',
      'Variance',
      'Unit Cost (ETB)',
      'Variance Impact (ETB)',
    ];

    const rows = dailyClosingItemSummaries.map((s) => {
      const it = items.find((i) => i.id === s.itemId);
      return [
        it?.code || '',
        `"${s.itemNameAm}"`,
        s.unitAm,
        s.beginningStock,
        s.receivedSIV,
        s.cashSaleQty,
        s.managementQty,
        s.staffMealQty,
        s.damageQty,
        s.totalOutQty,
        s.expectedClosingStock,
        s.actualPhysicalStock,
        s.varianceQty,
        s.unitCost,
        s.varianceCostETB,
      ];
    });

    const csvContent =
      '\uFEFF' +
      [
        `"የ${currentBranch.nameAm} የዕለት ሂሳብ እና ክምችት መዝጊያ ሪፖርት - ${closingDate} (${formatEthiopianDate(closingDate)})"`,
        `"ጠቅላላ የጥሬ ገንዘብ ሽያጭ: ${totalDayCashRevenue} ETB | የማኔጅመንት ወጪ: ${totalDayManagementCost} ETB | የስታፍ ምግብ ወጪ: ${totalDayStaffMealCost} ETB"`,
        headers.join(','),
        ...rows.map((e) => e.join(',')),
      ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `Branch_Closing_${currentBranch.code}_${closingDate}.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const printReport = () => {
    window.print();
  };

  if (!currentBranch || branches.length === 0) {
    return (
      <div className="bg-slate-900/80 rounded-3xl border border-amber-500/30 p-12 text-center shadow-2xl space-y-5 backdrop-blur-md max-w-2xl mx-auto">
        <div className="p-4 rounded-2xl bg-amber-950/80 text-amber-400 inline-block border border-amber-400/30">
          <Building2 className="w-12 h-12" />
        </div>
        <h2 className="text-xl font-black text-white">
          {language === 'am' ? 'የቅርንጫፍ ሌጀርን እና ሂሳብ መዝጊያን ለማንቀሳቀስ መጀመሪያ ቅርንጫፍ ይመዝግቡ' : 'No branches registered yet'}
        </h2>
        <p className="text-xs text-slate-300 leading-relaxed max-w-md mx-auto">
          {language === 'am'
            ? 'እያንዳንዱ ቅርንጫፍ የየራሱ የሆነ መነሻ ክምችት (Beginning Inventory)፣ ከስቶር በ SIV የሚገባለት፣ እንዲሁም 3 የቅነሳ መንገዶች (ቀጥታ ሽያጭ፣ ማኔጅመንት እና የስታፍ ምግብ) ይኖረዋል።'
            : 'Each branch maintains its own beginning inventory, SIV entries from main store, 3 deduction streams (cash sales, management, staff meals), and local account closing.'}
        </p>
        <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
          <button
            onClick={() => createDefaultThreeBranches()}
            className="px-5 py-2.5 bg-gradient-to-r from-amber-400 to-yellow-500 hover:from-amber-300 text-slate-950 rounded-xl text-xs font-black shadow-lg shadow-amber-500/25 ring-1 ring-amber-300"
          >
            + {language === 'am' ? '3ቱን ቅርንጫፎች ባዶ አድርገህ ፍጠር (ቦሌ፣ ፒያሳ፣ ሲኤምሲ)' : 'Quick Create 3 Blank Branches'}
          </button>
          <button
            onClick={onOpenNewBranch}
            className="px-4 py-2.5 bg-slate-900 border border-amber-500/40 hover:border-amber-400 text-amber-300 rounded-xl text-xs font-bold"
          >
            + {t.branches.addNewBranch}
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* View Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 no-print">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full bg-amber-500/10 text-amber-400 border border-amber-500/30 text-[11px] font-black uppercase tracking-wider">
              {language === 'am' ? 'የቅርንጫፎች ገለልተኛ ማኔጅመንት' : 'Autonomous Branch ERP'}
            </span>
          </div>
          <h1 className="text-xl sm:text-2xl font-black text-white flex items-center gap-2.5 mt-1">
            <GitBranch className="w-6 h-6 text-amber-400" />
            <span className="bg-gradient-to-r from-amber-200 via-amber-400 to-yellow-500 bg-clip-text text-transparent">
              {t.branches.title}
            </span>
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            {language === 'am'
              ? 'መነሻ ክምችት፣ ከስቶር በ SIV የገባ፣ 3 የሽያጭ እና ወጪ ቅነሳዎች (ቀጥታ ሽያጭ፣ ማኔጅመንት፣ የስታፍ ምግብ) እና የዕለት ሂሳብ መዝጊያ ሪፖርት'
              : 'Beginning stock, SIV receipts, 3 deduction channels (cash sales, management, staff meals), and daily account closing.'}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* Action 1: Set Beginning Stock */}
          <button
            onClick={() => setBeginningModalOpen(true)}
            className="flex items-center gap-1.5 px-3.5 py-2 bg-slate-900 border border-amber-500/40 hover:border-amber-400 text-amber-300 rounded-xl text-xs font-bold shadow-md transition-all"
          >
            <PlusCircle className="w-4 h-4 text-amber-400" />
            <span>{language === 'am' ? '+ መነሻ ክምችት አስገባ' : '+ Beginning Stock'}</span>
          </button>

          {/* Action 2: Receive SIV from Main Store */}
          <button
            onClick={() => onOpenTransfer(undefined, currentBranch.id)}
            className="flex items-center gap-1.5 px-3.5 py-2 bg-gradient-to-r from-blue-600 via-indigo-600 to-cyan-600 hover:from-blue-500 text-white rounded-xl text-xs font-bold shadow-lg shadow-blue-950/60 transition-all ring-1 ring-blue-400/40"
          >
            <ArrowRightLeft className="w-4 h-4" />
            <span>{language === 'am' ? 'ከስቶር በ SIV እቃ ተቀበል' : 'Receive SIV from Store'}</span>
          </button>

          {/* Action 3: Record 3-Way Usage / Sales */}
          <button
            onClick={() => onOpenBranchUsage(currentBranch.id)}
            className="flex items-center gap-1.5 px-4 py-2 bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-600 hover:from-amber-400 text-slate-950 rounded-xl text-xs font-black shadow-lg shadow-amber-950/60 transition-all ring-1 ring-amber-300/60"
          >
            <Flame className="w-4 h-4" />
            <span>{language === 'am' ? 'ሽያጭ / ወጪ ቅነስ (3 መንገዶች)' : 'Deduct Sales/Usage'}</span>
          </button>
        </div>
      </div>

      {/* Branch Selector Tabs (CRITICAL: Each branch is completely autonomous) */}
      <div className="flex items-center gap-2 border-b border-amber-500/20 pb-3 overflow-x-auto no-scrollbar no-print">
        {branches.map((br) => {
          const isSelected = br.id === selectedBranchId;
          return (
            <button
              key={br.id}
              onClick={() => setSelectedBranchId(br.id)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold text-xs sm:text-sm whitespace-nowrap transition-all ${
                isSelected
                  ? 'bg-gradient-to-r from-amber-400 to-yellow-500 text-slate-950 shadow-lg shadow-amber-500/25 ring-1 ring-amber-300/60 font-black'
                  : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-white hover:border-amber-500/30'
              }`}
            >
              <Building2 className="w-4 h-4" />
              <span>{language === 'am' ? br.nameAm : br.nameEn}</span>
              <span className={`px-1.5 py-0.5 rounded text-[10px] ${isSelected ? 'bg-slate-950 text-amber-300 font-bold' : 'bg-slate-800 text-slate-400'}`}>
                {br.code}
              </span>
            </button>
          );
        })}
      </div>

      {/* Branch Identity & Master Metrics Card */}
      {currentBranch && (
        <div className="bg-slate-900/80 rounded-3xl border border-amber-500/20 p-5 shadow-2xl backdrop-blur-md space-y-4 no-print">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <h2 className="text-lg sm:text-xl font-black text-white">
                  {language === 'am' ? currentBranch.nameAm : currentBranch.nameEn}
                </h2>
                <span className="px-2.5 py-0.5 rounded-full bg-amber-500/10 text-amber-300 border border-amber-500/30 text-xs font-bold">
                  {currentBranch.code}
                </span>
              </div>
              <div className="flex flex-wrap items-center gap-4 text-xs text-slate-400">
                <span className="flex items-center gap-1">
                  <MapPin className="w-3.5 h-3.5 text-amber-400" />
                  <span>{currentBranch.location}</span>
                </span>
                <span className="flex items-center gap-1">
                  <User className="w-3.5 h-3.5 text-amber-400" />
                  <span>{t.branches.manager}: <strong className="text-white">{currentBranch.manager}</strong></span>
                </span>
                <span className="flex items-center gap-1">
                  <Phone className="w-3.5 h-3.5 text-amber-400" />
                  <span>{currentBranch.phone}</span>
                </span>
              </div>
            </div>

            <div className="flex items-center gap-4 bg-slate-950 px-4 py-3 rounded-2xl border border-amber-500/30 shadow-inner">
              <div>
                <span className="text-[11px] text-slate-400 block font-semibold">
                  {language === 'am' ? 'የቅርንጫፉ ጠቅላላ ክምችት ዋጋ:' : 'Branch Inventory Value:'}
                </span>
                <span className="text-xl sm:text-2xl font-black text-amber-300">
                  {formatCurrency(totalBranchValue)}
                </span>
              </div>
            </div>
          </div>

          {/* Sub-Tabs: Live Balance vs Daily Closing vs Detailed Movement Ledger */}
          <div className="flex items-center gap-2 pt-3 border-t border-slate-800 text-xs overflow-x-auto no-scrollbar">
            <button
              onClick={() => setSelectedTab('balance')}
              className={`px-3.5 py-2 rounded-xl font-bold transition-all flex items-center gap-1.5 whitespace-nowrap ${
                selectedTab === 'balance'
                  ? 'bg-gradient-to-r from-amber-400 to-yellow-500 text-slate-950 shadow-md font-black ring-1 ring-amber-300'
                  : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-800'
              }`}
            >
              <Layers className="w-4 h-4" />
              <span>{language === 'am' ? '1. የክምችት ባላንስ' : '1. Stock Balance'}</span>
            </button>

            <button
              onClick={() => setSelectedTab('closing')}
              className={`px-3.5 py-2 rounded-xl font-bold transition-all flex items-center gap-1.5 whitespace-nowrap ${
                selectedTab === 'closing'
                  ? 'bg-gradient-to-r from-amber-400 to-yellow-500 text-slate-950 shadow-md font-black ring-1 ring-amber-300'
                  : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-800'
              }`}
            >
              <Receipt className="w-4 h-4 text-amber-400" />
              <span>{language === 'am' ? '2. የዕለት ሂሳብ መዝጊያ እና ሪፖርት' : '2. Daily Closing & Report'}</span>
              <span className="px-1.5 py-0.2 rounded bg-amber-950 text-amber-300 text-[10px] font-bold border border-amber-500/40">
                {language === 'am' ? 'ሪፖርት' : 'Report'}
              </span>
            </button>

            <button
              onClick={() => setSelectedTab('ledger')}
              className={`px-3.5 py-2 rounded-xl font-bold transition-all flex items-center gap-1.5 whitespace-nowrap ${
                selectedTab === 'ledger'
                  ? 'bg-gradient-to-r from-amber-400 to-yellow-500 text-slate-950 shadow-md font-black ring-1 ring-amber-300'
                  : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-800'
              }`}
            >
              <History className="w-4 h-4" />
              <span>{language === 'am' ? '3. የእንቅስቃሴ ሌጀር' : '3. Movement Ledger'}</span>
              <span className="px-1.5 py-0.2 rounded bg-slate-800 text-slate-300 text-[10px]">
                {filteredLedgerEntries.length}
              </span>
            </button>

            <button
              onClick={() => setSelectedTab('pastClosings')}
              className={`px-3.5 py-2 rounded-xl font-bold transition-all flex items-center gap-1.5 whitespace-nowrap ${
                selectedTab === 'pastClosings'
                  ? 'bg-gradient-to-r from-amber-400 to-yellow-500 text-slate-950 shadow-md font-black ring-1 ring-amber-300'
                  : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-800'
              }`}
            >
              <Lock className="w-4 h-4" />
              <span>{language === 'am' ? 'የተዘጉ ሪፖርቶች ማህደር' : 'Past Closed Reports'}</span>
              <span className="px-1.5 py-0.2 rounded bg-slate-800 text-slate-300 text-[10px]">
                {branchDailyClosings.filter((c) => c.branchId === currentBranch.id).length}
              </span>
            </button>
          </div>
        </div>
      )}

      {/* =========================================================================
          TAB 1: LIVE BRANCH STOCK BALANCE (Beginning + SIV - 3 Deductions = Balance)
          ========================================================================= */}
      {selectedTab === 'balance' && (
        <div className="bg-slate-900/80 rounded-3xl border border-amber-500/20 shadow-2xl overflow-hidden backdrop-blur-md space-y-4">
          <div className="p-4 bg-slate-950/80 border-b border-amber-500/20 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h3 className="text-sm font-black text-white flex items-center gap-2">
                <Layers className="w-4 h-4 text-amber-400" />
                <span>{language === 'am' ? `${currentBranch.nameAm} — አጠቃላይ የክምችት ባላንስ` : `${currentBranch.nameEn} — Live Stock Balances`}</span>
              </h3>
              <p className="text-[11px] text-slate-400">
                {language === 'am'
                  ? 'መነሻ ክምችት + ከስቶር በ SIV የገባ - ቀጥታ ሽያጭ - ማኔጅመንት - የስታፍ ምግብ = አሁን ያለው ባላንስ'
                  : 'Beginning + SIV In - Cash Sales - Management - Staff Meal = Current Branch Stock'}
              </p>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setBeginningModalOpen(true)}
                className="px-3 py-1.5 bg-slate-900 text-amber-300 border border-amber-500/40 rounded-xl text-xs font-bold hover:bg-slate-800 flex items-center gap-1.5"
              >
                <PlusCircle className="w-3.5 h-3.5 text-amber-400" />
                <span>{language === 'am' ? 'መነሻ ክምችት አስገባ' : 'Set Beginning Stock'}</span>
              </button>
              <button
                onClick={() => onOpenBranchUsage(currentBranch.id)}
                className="px-3.5 py-1.5 bg-gradient-to-r from-amber-400 to-yellow-500 text-slate-950 font-black rounded-xl text-xs shadow-md shadow-amber-500/20 flex items-center gap-1.5"
              >
                <Flame className="w-3.5 h-3.5" />
                <span>{language === 'am' ? 'ሽያጭ / ወጪ ቀንሰው' : 'Deduct Sales'}</span>
              </button>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-950/90 text-slate-300 font-bold border-b border-amber-500/20 text-[11px] uppercase tracking-wider">
                  <th className="py-3 px-4">{language === 'am' ? 'ኮድ' : 'Code'}</th>
                  <th className="py-3 px-4">{t.common.item}</th>
                  <th className="py-3 px-4 text-center">{t.common.unit}</th>
                  <th className="py-3 px-4 text-right bg-slate-950 text-slate-200">
                    {language === 'am' ? 'መነሻ ክምችት' : 'Beginning'}
                  </th>
                  <th className="py-3 px-4 text-right bg-blue-950/30 text-blue-300 font-bold">
                    {language === 'am' ? '+ SIV የገባ' : '+ SIV In'}
                  </th>
                  <th className="py-3 px-4 text-right bg-emerald-950/30 text-emerald-300 font-bold">
                    {language === 'am' ? '- ቀጥታ ሽያጭ' : '- Cash Sale'}
                  </th>
                  <th className="py-3 px-4 text-right bg-indigo-950/30 text-indigo-300 font-bold">
                    {language === 'am' ? '- ማኔጅመንት' : '- Mgt Use'}
                  </th>
                  <th className="py-3 px-4 text-right bg-amber-950/40 text-amber-300 font-bold">
                    {language === 'am' ? '- የስታፍ ምግብ' : '- Staff Meal'}
                  </th>
                  <th className="py-3 px-4 text-right font-black bg-slate-950 text-amber-300 text-xs">
                    {language === 'am' ? '= አሁን ያለው ክምችት' : '= Current Stock'}
                  </th>
                  <th className="py-3 px-4 text-right">{t.centralStore.avgCost}</th>
                  <th className="py-3 px-4 text-right font-black text-amber-300">{t.common.totalPrice}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 bg-slate-900/40">
                {branchStockItems.length === 0 ? (
                  <tr>
                    <td colSpan={11} className="py-8 text-center text-slate-400">
                      {language === 'am' ? 'እስካሁን ምንም ጥሬ ዕቃ አልተመዘገበም' : 'No inventory items registered yet'}
                    </td>
                  </tr>
                ) : (
                  branchStockItems.map((item) => (
                    <tr key={item.id} className="hover:bg-amber-500/[0.04]">
                      <td className="py-3 px-4 font-mono font-bold text-amber-300">{item.code}</td>
                      <td className="py-3 px-4 font-bold text-white">
                        {language === 'am' ? item.nameAm : item.nameEn}
                      </td>
                      <td className="py-3 px-4 text-center text-slate-300">{item.unitAm}</td>
                      <td className="py-3 px-4 text-right font-mono text-slate-300 bg-slate-950/50">
                        {item.beginningStock > 0 ? `${item.beginningStock}` : '0'}
                      </td>
                      <td className="py-3 px-4 text-right font-mono font-bold text-blue-300 bg-blue-950/10">
                        {item.totalSivIn > 0 ? `+${item.totalSivIn}` : '—'}
                      </td>
                      <td className="py-3 px-4 text-right font-mono font-bold text-emerald-400 bg-emerald-950/10">
                        {item.cashSalesOut > 0 ? `-${item.cashSalesOut}` : '—'}
                      </td>
                      <td className="py-3 px-4 text-right font-mono font-bold text-indigo-300 bg-indigo-950/10">
                        {item.managementOut > 0 ? `-${item.managementOut}` : '—'}
                      </td>
                      <td className="py-3 px-4 text-right font-mono font-bold text-amber-300 bg-amber-950/20">
                        {item.staffMealOut > 0 ? `-${item.staffMealOut}` : '—'}
                      </td>
                      <td className="py-3 px-4 text-right font-mono font-black text-amber-300 bg-slate-950/80 text-sm">
                        {item.branchBalance} {item.unitAm}
                      </td>
                      <td className="py-3 px-4 text-right text-slate-300 font-mono">
                        {formatCurrency(item.weightedAvgCost)}
                      </td>
                      <td className="py-3 px-4 text-right font-black text-amber-300 font-mono">
                        {formatCurrency(item.totalVal)}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* =========================================================================
          TAB 2: DAILY ACCOUNT CLOSING & SETTLEMENT REPORT (CRITICAL USER REQUEST)
          "ሂሳቡ በየብራንቾቹ ከተዘጋ በኋላ ሪፖርት መቅረብ አለበት። እቺን ነገር በደንብ ስራልኝ።"
          ========================================================================= */}
      {selectedTab === 'closing' && (
        <div className="space-y-6">
          {/* Closing Controls Header */}
          <div className="bg-slate-900/80 rounded-3xl border border-amber-500/20 p-5 shadow-2xl backdrop-blur-md space-y-4 no-print">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <div className="flex items-center gap-2">
                  <Receipt className="w-5 h-5 text-amber-400" />
                  <h2 className="text-base sm:text-lg font-black text-white">
                    {language === 'am' ? `የ${currentBranch.nameAm} የዕለት ሂሳብ እና ክምችት መዝጊያ ሪፖርት` : `Daily Settlement & Closing Report — ${currentBranch.nameEn}`}
                  </h2>
                </div>
                <p className="text-xs text-slate-400 mt-1">
                  {language === 'am'
                    ? 'በዚህ ቀን የተከናወነውን መነሻ፣ SIV ገቢ፣ ቀጥታ ሽያጭ፣ ማኔጅመንት እና የስታፍ ምግብ ተቀናንሶ የተገኘውን የዕለት ሂሳብ መዝጊያ ሪፖርት ያዘጋጁ።'
                    : 'Audit all inflows, cash sales, management allowances, and staff meals. Reconcile physical inventory and lock the daily book.'}
                </p>
              </div>

              {/* Date Selector for Closing */}
              <div className="flex items-center gap-2">
                <DatePickerField
                  label={language === 'am' ? 'የመዝጊያ ቀን ይምረጡ' : 'Select Closing Date'}
                  value={closingDate}
                  onChange={setClosingDate}
                  required
                />
              </div>
            </div>

            {/* Financial Summary KPI Cards for the day */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 pt-2">
              {/* Card 1: Total Cash Sales Revenue */}
              <div className="bg-slate-950 p-4 rounded-2xl border border-emerald-500/30 shadow-inner">
                <span className="text-[11px] text-emerald-400 font-bold block flex items-center gap-1">
                  <DollarSign className="w-3.5 h-3.5" />
                  <span>{language === 'am' ? 'የተሰበሰበ ጥሬ ገንዘብ (Cash Sales)' : 'Cash Revenue'}</span>
                </span>
                <span className="text-lg sm:text-xl font-black text-white font-mono mt-1 block">
                  {formatCurrency(totalDayCashRevenue)}
                </span>
                <span className="text-[10px] text-slate-400">
                  {language === 'am' ? 'በቀጥታ ሽያጭ የተሰበሰበ' : 'From Direct Customer Cash Sales'}
                </span>
              </div>

              {/* Card 2: Total Management Consumption Cost */}
              <div className="bg-slate-950 p-4 rounded-2xl border border-blue-500/30 shadow-inner">
                <span className="text-[11px] text-blue-400 font-bold block flex items-center gap-1">
                  <Briefcase className="w-3.5 h-3.5" />
                  <span>{language === 'am' ? 'የማኔጅመንት ወጪ (Mgt Cost)' : 'Management Cost'}</span>
                </span>
                <span className="text-lg sm:text-xl font-black text-white font-mono mt-1 block">
                  {formatCurrency(totalDayManagementCost)}
                </span>
                <span className="text-[10px] text-slate-400">
                  {language === 'am' ? 'ለስራ አመራር የወጣ የወጪ ዋጋ' : 'Management Consumption Cost'}
                </span>
              </div>

              {/* Card 3: Total Staff Meal Cost */}
              <div className="bg-slate-950 p-4 rounded-2xl border border-amber-500/30 shadow-inner">
                <span className="text-[11px] text-amber-400 font-bold block flex items-center gap-1">
                  <Users className="w-3.5 h-3.5" />
                  <span>{language === 'am' ? 'የስታፍ ምግብ ወጪ (Staff Food)' : 'Staff Meal Cost'}</span>
                </span>
                <span className="text-lg sm:text-xl font-black text-amber-300 font-mono mt-1 block">
                  {formatCurrency(totalDayStaffMealCost)}
                </span>
                <span className="text-[10px] text-slate-400">
                  {language === 'am' ? 'የሰራተኞች ምግብ የወጪ ዋጋ' : 'Staff Meal Cost Value'}
                </span>
              </div>

              {/* Card 4: Inventory Discrepancy Impact */}
              <div className="bg-slate-950 p-4 rounded-2xl border border-rose-500/30 shadow-inner">
                <span className="text-[11px] text-rose-400 font-bold block flex items-center gap-1">
                  <AlertTriangle className="w-3.5 h-3.5" />
                  <span>{language === 'am' ? 'የቆጠራ ልዩነት/ብክነት ዋጋ' : 'Variance Impact'}</span>
                </span>
                <span className={`text-lg sm:text-xl font-black font-mono mt-1 block ${totalVarianceCost !== 0 ? 'text-rose-400' : 'text-emerald-400'}`}>
                  {formatCurrency(Math.abs(totalVarianceCost))}
                </span>
                <span className="text-[10px] text-slate-400">
                  {totalVarianceCost === 0
                    ? (language === 'am' ? 'ቆጠራው ሙሉ በሙሉ ተመጣጣኝ ነው' : 'Count fully balanced')
                    : totalVarianceCost < 0
                    ? (language === 'am' ? 'የክምችት ጉድለት ተገኝቷል' : 'Inventory shortage')
                    : (language === 'am' ? 'ትርፍ ክምችት ተገኝቷል' : 'Excess stock')}
                </span>
              </div>
            </div>

            {/* Closing Actions Bar */}
            <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-slate-800">
              <div className="flex items-center gap-2">
                <span className="text-xs text-slate-400">
                  {language === 'am' ? 'የዕለቱ ሁኔታ:' : 'Status:'}{' '}
                  {existingDayClosing ? (
                    <strong className="text-emerald-400">✓ {language === 'am' ? `ሂሳቡ ተዘግቷል (${existingDayClosing.closingNumber})` : `Closed (${existingDayClosing.closingNumber})`}</strong>
                  ) : (
                    <strong className="text-amber-400">⏳ {language === 'am' ? 'ያልተዘጋ ረቂቅ (Draft)' : 'Open / Draft'}</strong>
                  )}
                </span>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={exportDailyClosingCSV}
                  className="px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-700 hover:border-amber-400 text-slate-300 hover:text-white text-xs font-bold transition-all flex items-center gap-1.5"
                >
                  <Download className="w-4 h-4 text-amber-400" />
                  <span>{language === 'am' ? 'CSV አውርድ' : 'Export CSV'}</span>
                </button>

                <button
                  onClick={printReport}
                  className="px-3.5 py-2 rounded-xl bg-slate-950 border border-amber-500/40 hover:border-amber-400 text-amber-300 text-xs font-bold transition-all flex items-center gap-1.5"
                >
                  <Printer className="w-4 h-4 text-amber-400" />
                  <span>{language === 'am' ? 'ሪፖርት አትም' : 'Print Voucher'}</span>
                </button>

                <button
                  onClick={handleFinalizeDailyClosing}
                  className="px-5 py-2 bg-gradient-to-r from-amber-400 to-yellow-500 hover:from-amber-300 text-slate-950 rounded-xl text-xs font-black shadow-lg shadow-amber-500/25 ring-1 ring-amber-300 flex items-center gap-1.5"
                >
                  <Lock className="w-4 h-4" />
                  <span>{language === 'am' ? 'የዕለቱን ሂሳብ ዝጋ እና ሪፖርት አውጣ' : 'Finalize & Lock Daily Closing'}</span>
                </button>
              </div>
            </div>

            {closingSuccessMsg && (
              <div className="p-3 bg-emerald-950/80 border border-emerald-500/50 rounded-2xl flex items-center gap-2 text-emerald-300 text-xs">
                <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
                <span>{language === 'am' ? `የ${currentBranch.nameAm} የዕለት ሂሳብ እና ሪፖርት በተሳካ ሁኔታ ተዘግቶ በቋሚነት ተቀምጧል!` : 'Daily closing successfully finalized and archived!'}</span>
              </div>
            )}
          </div>

          {/* Official Printable Daily Closing Voucher & Table */}
          <div className="bg-slate-900/90 rounded-3xl border border-amber-500/30 shadow-2xl p-6 backdrop-blur-md space-y-6 print:bg-white print:text-black print:p-0 print:border-none print:shadow-none">
            {/* Voucher Header (for print & executive view) */}
            <div className="border-b border-amber-500/30 pb-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <span className="text-[10px] font-bold text-amber-400 uppercase tracking-widest block">
                  ETHIOPIAN RESTAURANT & HOSPITALITY ENTERPRISE
                </span>
                <h2 className="text-xl font-black text-white print:text-black">
                  {language === 'am' ? `የዕለት ሂሳብ እና የክምችት ማጠቃለያ ሪፖርት` : `Daily Inventory & Cash Settlement Report`}
                </h2>
                <div className="text-xs text-slate-400 print:text-slate-700 flex flex-wrap items-center gap-3 mt-1">
                  <span><strong>{language === 'am' ? 'ቅርንጫፍ:' : 'Branch:'}</strong> {currentBranch.nameAm} ({currentBranch.code})</span>
                  <span>•</span>
                  <span><strong>{language === 'am' ? 'የመዝጊያ ቀን:' : 'Date:'}</strong> {closingDate} (🇪🇹 {formatEthiopianDate(closingDate)})</span>
                  <span>•</span>
                  <span><strong>{language === 'am' ? 'ስራ አስኪያጅ:' : 'Manager:'}</strong> {currentBranch.manager}</span>
                </div>
              </div>

              <div className="text-right font-mono bg-slate-950 print:bg-slate-100 p-3 rounded-2xl border border-amber-500/30 print:border-slate-300">
                <span className="text-[10px] text-slate-400 block font-semibold">
                  {language === 'am' ? 'የሰነድ / የመዝጊያ ቁጥር:' : 'Voucher Ref:'}
                </span>
                <span className="text-xs font-black text-amber-300 print:text-slate-900">
                  CLS-{currentBranch.code}-{closingDate.replace(/-/g, '')}
                </span>
              </div>
            </div>

            {/* Comprehensive Item Breakdown Table */}
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs print:text-[10px]">
                <thead>
                  <tr className="bg-slate-950 text-slate-300 print:bg-slate-200 print:text-slate-900 font-bold border-b border-amber-500/20 text-[11px] uppercase tracking-wider">
                    <th className="py-2.5 px-3">{language === 'am' ? 'ጥሬ ዕቃ' : 'Item'}</th>
                    <th className="py-2.5 px-2 text-center">{language === 'am' ? 'መለኪያ' : 'Unit'}</th>
                    <th className="py-2.5 px-2 text-right bg-slate-950/80">
                      {language === 'am' ? '1. መነሻ' : 'Beg Stock'}
                    </th>
                    <th className="py-2.5 px-2 text-right bg-blue-950/30 text-blue-300 font-bold">
                      {language === 'am' ? '2. + SIV ገቢ' : '+ SIV In'}
                    </th>
                    <th className="py-2.5 px-2 text-right bg-emerald-950/30 text-emerald-300 font-bold">
                      {language === 'am' ? '3. - ቀጥታ ሽያጭ' : '- Cash Sale'}
                    </th>
                    <th className="py-2.5 px-2 text-right bg-indigo-950/30 text-indigo-300 font-bold">
                      {language === 'am' ? '4. - ማኔጅመንት' : '- Mgt Use'}
                    </th>
                    <th className="py-2.5 px-2 text-right bg-amber-950/40 text-amber-300 font-bold">
                      {language === 'am' ? '5. - የስታፍ ምግብ' : '- Staff Meal'}
                    </th>
                    <th className="py-2.5 px-2 text-right bg-rose-950/30 text-rose-300 font-bold">
                      {language === 'am' ? '6. - ብክነት' : '- Damage'}
                    </th>
                    <th className="py-2.5 px-2 text-right bg-slate-950 text-white font-bold">
                      {language === 'am' ? '7. ጠቅላላ የወጣ' : 'Total Out'}
                    </th>
                    <th className="py-2.5 px-2 text-right bg-amber-950/20 text-amber-300 font-black">
                      {language === 'am' ? '8. የሚጠበቅ ቀሪ' : 'Expected Bal'}
                    </th>
                    <th className="py-2.5 px-3 text-right bg-slate-950 text-white font-black no-print">
                      {language === 'am' ? '9. የተቆጠረ (Physical Count)' : 'Count'}
                    </th>
                    <th className="py-2.5 px-2 text-right font-black">
                      {language === 'am' ? '10. ልዩነት' : 'Variance'}
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 bg-slate-900/40 print:bg-white print:divide-slate-200">
                  {dailyClosingItemSummaries.map((row) => (
                    <tr key={row.itemId} className="hover:bg-amber-500/[0.04]">
                      <td className="py-2 px-3 font-bold text-white print:text-black">
                        {row.itemNameAm}
                      </td>
                      <td className="py-2 px-2 text-center text-slate-400 print:text-slate-600">
                        {row.unitAm}
                      </td>
                      <td className="py-2 px-2 text-right font-mono text-slate-300 print:text-black">
                        {row.beginningStock}
                      </td>
                      <td className="py-2 px-2 text-right font-mono font-bold text-blue-300 print:text-blue-700 bg-blue-950/10">
                        {row.receivedSIV > 0 ? `+${row.receivedSIV}` : '—'}
                      </td>
                      <td className="py-2 px-2 text-right font-mono font-bold text-emerald-400 print:text-emerald-700 bg-emerald-950/10">
                        {row.cashSaleQty > 0 ? `-${row.cashSaleQty}` : '—'}
                      </td>
                      <td className="py-2 px-2 text-right font-mono font-bold text-indigo-300 print:text-indigo-700 bg-indigo-950/10">
                        {row.managementQty > 0 ? `-${row.managementQty}` : '—'}
                      </td>
                      <td className="py-2 px-2 text-right font-mono font-bold text-amber-300 print:text-amber-700 bg-amber-950/20">
                        {row.staffMealQty > 0 ? `-${row.staffMealQty}` : '—'}
                      </td>
                      <td className="py-2 px-2 text-right font-mono text-rose-400 print:text-rose-700 bg-rose-950/10">
                        {row.damageQty > 0 ? `-${row.damageQty}` : '—'}
                      </td>
                      <td className="py-2 px-2 text-right font-mono font-bold text-slate-200 print:text-black bg-slate-950/40">
                        {row.totalOutQty}
                      </td>
                      <td className="py-2 px-2 text-right font-mono font-black text-amber-300 print:text-black bg-amber-950/20">
                        {row.expectedClosingStock}
                      </td>
                      {/* Physical count interactive input */}
                      <td className="py-2 px-3 text-right bg-slate-950/90 no-print">
                        <input
                          type="number"
                          step="any"
                          value={
                            closingPhysicalCounts[row.itemId] !== undefined
                              ? closingPhysicalCounts[row.itemId]
                              : row.expectedClosingStock
                          }
                          onChange={(e) =>
                            setClosingPhysicalCounts({
                              ...closingPhysicalCounts,
                              [row.itemId]: e.target.value === '' ? 0 : parseFloat(e.target.value),
                            })
                          }
                          className="w-20 px-2 py-1 bg-slate-900 border border-slate-700 rounded-lg text-xs text-white text-right font-mono font-bold focus:outline-none focus:ring-1 focus:ring-amber-400"
                        />
                      </td>
                      <td className="py-2 px-2 text-right font-mono font-bold">
                        {row.varianceQty === 0 ? (
                          <span className="text-emerald-400 print:text-emerald-700">0.00 ✓</span>
                        ) : row.varianceQty < 0 ? (
                          <span className="text-rose-400 print:text-rose-700 font-black">{row.varianceQty} {row.unitAm}</span>
                        ) : (
                          <span className="text-cyan-400 print:text-cyan-700 font-black">+{row.varianceQty} {row.unitAm}</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Official Closing Signatures section for Print & Audit */}
            <div className="pt-8 border-t border-amber-500/20 grid grid-cols-3 gap-6 text-xs text-center">
              <div className="space-y-6">
                <div className="border-b border-dashed border-slate-700 pb-8 text-slate-500">
                  {/* Signature line */}
                </div>
                <div>
                  <strong className="block text-white print:text-black">{language === 'am' ? 'የቅርንጫፍ ገንዘብ ያዥ (ካሼር)' : 'Branch Cashier'}</strong>
                  <span className="text-[11px] text-slate-400 print:text-slate-600">{language === 'am' ? 'ስም እና ፊርማ' : 'Name & Signature'}</span>
                </div>
              </div>

              <div className="space-y-6">
                <div className="border-b border-dashed border-slate-700 pb-8 text-slate-500">
                  {/* Signature line */}
                </div>
                <div>
                  <strong className="block text-white print:text-black">{language === 'am' ? 'የቅርንጫፍ ስቶር ኪፐር' : 'Branch Storekeeper'}</strong>
                  <span className="text-[11px] text-slate-400 print:text-slate-600">{language === 'am' ? 'ስም እና ፊርማ' : 'Name & Signature'}</span>
                </div>
              </div>

              <div className="space-y-6">
                <div className="border-b border-dashed border-slate-700 pb-8 text-slate-500">
                  {/* Signature line */}
                </div>
                <div>
                  <strong className="block text-white print:text-black">{currentBranch.manager || (language === 'am' ? 'የቅርንጫፍ ስራ አስኪያጅ' : 'Branch Manager')}</strong>
                  <span className="text-[11px] text-slate-400 print:text-slate-600">{language === 'am' ? 'አጽዳቂ ኃላፊ ፊርማ' : 'Approved by Manager'}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          TAB 3: DETAILED MOVEMENT LEDGER (AUDIT TRAIL)
          ========================================================================= */}
      {selectedTab === 'ledger' && (
        <div className="bg-slate-900/80 rounded-3xl border border-amber-500/20 shadow-2xl overflow-hidden backdrop-blur-md space-y-4">
          <div className="p-4 bg-slate-950/80 border-b border-amber-500/20 no-print">
            <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
              <div>
                <DatePickerField
                  label={language === 'am' ? 'ከቀን (Start Date)' : 'From Date'}
                  value={startDate}
                  onChange={setStartDate}
                />
              </div>
              <div>
                <DatePickerField
                  label={language === 'am' ? 'እስከ ቀን (End Date)' : 'To Date'}
                  value={endDate}
                  onChange={setEndDate}
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-amber-300 mb-1.5">
                  {language === 'am' ? 'የእንቅስቃሴ አይነት' : 'Movement Type'}
                </label>
                <select
                  value={filterType}
                  onChange={(e) => setFilterType(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:border-amber-400"
                >
                  <option value="ALL">{t.common.all}</option>
                  <option value="BEGINNING_STOCK">{language === 'am' ? 'መነሻ ክምችት' : 'Beginning Stock'}</option>
                  <option value="TRANSFER_IN">{language === 'am' ? 'ከስቶር በ SIV የገባ' : 'SIV Receipt'}</option>
                  <option value="CASH_SALE">{language === 'am' ? '1. ቀጥታ በገንዘብ የተሸጠ' : '1. Cash Sale'}</option>
                  <option value="MANAGEMENT_USE">{language === 'am' ? '2. ማኔጅመንት የተጠቀመው' : '2. Management Use'}</option>
                  <option value="STAFF_MEAL">{language === 'am' ? '3. የስታፍ ምግብ' : '3. Staff Meal'}</option>
                  <option value="WASTE_DAMAGE">{language === 'am' ? 'ብክነት / ብልሽት' : 'Waste/Damage'}</option>
                  <option value="RECONCILIATION_ADJ">{language === 'am' ? 'የቆጠራ ማስተካከያ' : 'Reconciliation Adj'}</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-bold text-amber-300 mb-1.5">
                  {language === 'am' ? 'በጥሬ እቃ አጣራ' : 'Filter by Item'}
                </label>
                <select
                  value={filterItemId}
                  onChange={(e) => setFilterItemId(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:border-amber-400"
                >
                  <option value="ALL">{t.common.all}</option>
                  {items.map((it) => (
                    <option key={it.id} value={it.id}>
                      {language === 'am' ? it.nameAm : it.nameEn}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-950/90 text-slate-300 font-bold uppercase tracking-wider text-[11px] border-b border-amber-500/20">
                  <th className="py-3 px-4">{t.common.date}</th>
                  <th className="py-3 px-4">{t.common.refNo}</th>
                  <th className="py-3 px-4">{t.common.item}</th>
                  <th className="py-3 px-4">{language === 'am' ? 'የእንቅስቃሴ አይነት' : 'Type'}</th>
                  <th className="py-3 px-4 text-right bg-emerald-950/30 text-emerald-300 font-black">
                    {language === 'am' ? 'ገቢ (+In)' : 'In'}
                  </th>
                  <th className="py-3 px-4 text-right bg-rose-950/30 text-rose-300 font-black">
                    {language === 'am' ? 'ወጪ (-Out)' : 'Out'}
                  </th>
                  <th className="py-3 px-4 text-right font-black bg-slate-950 text-amber-300">
                    {language === 'am' ? 'የቅርንጫፍ ቀሪ (Bal)' : 'Branch Bal'}
                  </th>
                  <th className="py-3 px-4 text-right">{language === 'am' ? 'የጥሬ ገንዘብ ገቢ' : 'Cash Revenue'}</th>
                  <th className="py-3 px-4">{language === 'am' ? 'ዝርዝር / ተጠቃሚ' : 'Details / Beneficiary'}</th>
                  <th className="py-3 px-4">{t.common.recordedBy}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 bg-slate-900/40">
                {filteredLedgerEntries.length === 0 ? (
                  <tr>
                    <td colSpan={10} className="py-8 text-center text-slate-400">
                      {language === 'am'
                        ? 'በዚህ ቀን ለዚህ ቅርንጫፍ የተመዘገበ የሌጀር እንቅስቃሴ የለም'
                        : 'No transactions found for this branch in selected filter'}
                    </td>
                  </tr>
                ) : (
                  filteredLedgerEntries.map((entry) => {
                    const it = items.find((i) => i.id === entry.itemId);
                    return (
                      <tr key={entry.id} className="hover:bg-amber-500/[0.04]">
                        <td className="py-3 px-4 whitespace-nowrap">
                          <div className="font-bold text-white">{entry.date}</div>
                          <div className="text-[10px] text-amber-400 font-semibold">🇪🇹 {entry.ethiopianDateStr}</div>
                        </td>
                        <td className="py-3 px-4 font-mono font-semibold text-amber-300 whitespace-nowrap">
                          {entry.refNo}
                        </td>
                        <td className="py-3 px-4 font-bold text-white">
                          {it ? (language === 'am' ? it.nameAm : it.nameEn) : entry.itemId}
                        </td>
                        <td className="py-3 px-4 whitespace-nowrap">
                          {entry.type === 'BEGINNING_STOCK' && (
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-800 text-slate-200 border border-slate-600">
                              {language === 'am' ? 'መነሻ ክምችት' : 'Beginning'}
                            </span>
                          )}
                          {entry.type === 'TRANSFER_IN' && (
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-blue-950 text-blue-300 border border-blue-800/50">
                              {language === 'am' ? 'ከስቶር በ SIV የገባ' : 'SIV In'}
                            </span>
                          )}
                          {(entry.type === 'CASH_SALE' || entry.type === 'DIRECT_SALE') && (
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-950 text-emerald-300 border border-emerald-800/50">
                              {language === 'am' ? '1. ቀጥታ ሽያጭ' : '1. Cash Sale'}
                            </span>
                          )}
                          {entry.type === 'MANAGEMENT_USE' && (
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-indigo-950 text-indigo-300 border border-indigo-800/50">
                              {language === 'am' ? '2. ማኔጅመንት' : '2. Management'}
                            </span>
                          )}
                          {(entry.type === 'STAFF_MEAL' || entry.type === 'KITCHEN_USAGE') && (
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-950 text-amber-300 border border-amber-800/50">
                              {language === 'am' ? '3. የስታፍ ምግብ' : '3. Staff Meal'}
                            </span>
                          )}
                          {entry.type === 'WASTE_DAMAGE' && (
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-950 text-rose-300 border border-rose-800/50">
                              {language === 'am' ? 'ብክነት' : 'Waste'}
                            </span>
                          )}
                          {entry.type === 'RECONCILIATION_ADJ' && (
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-purple-950 text-purple-300 border border-purple-800/50">
                              {language === 'am' ? 'የቆጠራ ማስተካከያ' : 'Adj'}
                            </span>
                          )}
                        </td>
                        <td className="py-3 px-4 text-right font-black text-emerald-400 bg-emerald-950/20 font-mono">
                          {entry.quantityIn > 0 ? `+${entry.quantityIn} ${it?.unitAm || ''}` : '—'}
                        </td>
                        <td className="py-3 px-4 text-right font-black text-rose-400 bg-rose-950/20 font-mono">
                          {entry.quantityOut > 0 ? `-${entry.quantityOut} ${it?.unitAm || ''}` : '—'}
                        </td>
                        <td className="py-3 px-4 text-right font-black text-amber-300 bg-slate-950/80 font-mono">
                          {entry.balance} {it?.unitAm || ''}
                        </td>
                        <td className="py-3 px-4 text-right font-mono font-bold text-emerald-400">
                          {entry.cashRevenue ? formatCurrency(entry.cashRevenue) : '—'}
                        </td>
                        <td className="py-3 px-4 text-white">
                          <div className="font-semibold">{entry.reasonOrMenu}</div>
                          {entry.beneficiaryOrGuest && (
                            <div className="text-[10px] text-amber-400 font-bold">
                              {language === 'am' ? 'ተጠቃሚ:' : 'Beneficiary:'} {entry.beneficiaryOrGuest}
                            </div>
                          )}
                        </td>
                        <td className="py-3 px-4 text-slate-400 text-[11px] whitespace-nowrap">
                          {entry.recordedBy}
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* =========================================================================
          TAB 4: PAST CLOSED DAILY REPORTS ARCHIVE
          ========================================================================= */}
      {selectedTab === 'pastClosings' && (
        <div className="bg-slate-900/80 rounded-3xl border border-amber-500/20 shadow-2xl p-6 backdrop-blur-md space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Lock className="w-4 h-4 text-amber-400" />
                <span>{language === 'am' ? `የ${currentBranch.nameAm} የተዘጉ የዕለት ሂሳቦች ማህደር` : `Past Closed Daily Reports — ${currentBranch.nameEn}`}</span>
              </h3>
              <p className="text-[11px] text-slate-400">
                {language === 'am' ? 'በዚህ ቅርንጫፍ የተዘጉ ያለፉ ቀናት የሂሳብ እና የክምችት ሪፖርቶች' : 'Historical finalized shift and day closings.'}
              </p>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-950 text-slate-300 font-bold border-b border-amber-500/20 text-[11px] uppercase tracking-wider">
                  <th className="py-3 px-4">{language === 'am' ? 'የመዝጊያ ቁጥር' : 'Ref No'}</th>
                  <th className="py-3 px-4">{t.common.date}</th>
                  <th className="py-3 px-4 text-right text-emerald-400 font-bold">{language === 'am' ? 'የጥሬ ገንዘብ ሽያጭ' : 'Cash Sales'}</th>
                  <th className="py-3 px-4 text-right text-blue-400 font-bold">{language === 'am' ? 'የማኔጅመንት ወጪ' : 'Management Cost'}</th>
                  <th className="py-3 px-4 text-right text-amber-400 font-bold">{language === 'am' ? 'የስታፍ ምግብ ወጪ' : 'Staff Meal Cost'}</th>
                  <th className="py-3 px-4 text-right text-rose-400 font-bold">{language === 'am' ? 'የልዩነት ዋጋ' : 'Variance Cost'}</th>
                  <th className="py-3 px-4">{language === 'am' ? 'የዘጋው ኃላፊ' : 'Closed By'}</th>
                  <th className="py-3 px-4 text-center">{t.common.actions}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 bg-slate-900/40">
                {branchDailyClosings.filter((c) => c.branchId === currentBranch.id).length === 0 ? (
                  <tr>
                    <td colSpan={8} className="py-8 text-center text-slate-400">
                      {language === 'am' ? 'እስካሁን የተዘጋ የዕለት ሂሳብ የለም። "የዕለት ሂሳብ መዝጊያ እና ሪፖርት" ገጽ ላይ ገብተው ይዝጉ።' : 'No closed accounts yet.'}
                    </td>
                  </tr>
                ) : (
                  branchDailyClosings
                    .filter((c) => c.branchId === currentBranch.id)
                    .map((closing) => (
                      <tr key={closing.id} className="hover:bg-amber-500/[0.04]">
                        <td className="py-3 px-4 font-mono font-bold text-amber-300">{closing.closingNumber}</td>
                        <td className="py-3 px-4">
                          <span className="font-bold text-white">{closing.date}</span>
                          <span className="text-[10px] text-amber-400 block font-semibold">🇪🇹 {closing.ethiopianDateStr}</span>
                        </td>
                        <td className="py-3 px-4 text-right font-mono font-bold text-emerald-400">
                          {formatCurrency(closing.totalCashSalesETB)}
                        </td>
                        <td className="py-3 px-4 text-right font-mono font-bold text-blue-300">
                          {formatCurrency(closing.totalManagementCostETB)}
                        </td>
                        <td className="py-3 px-4 text-right font-mono font-bold text-amber-300">
                          {formatCurrency(closing.totalStaffMealCostETB)}
                        </td>
                        <td className="py-3 px-4 text-right font-mono font-bold text-rose-400">
                          {formatCurrency(closing.totalVarianceCostETB)}
                        </td>
                        <td className="py-3 px-4 text-slate-300">{closing.closedBy}</td>
                        <td className="py-3 px-4 text-center">
                          <button
                            onClick={() => {
                              setClosingDate(closing.date);
                              setSelectedTab('closing');
                            }}
                            className="px-3 py-1 bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 rounded-xl text-xs font-bold transition-all"
                          >
                            {language === 'am' ? 'ሪፖርቱን ክፈት' : 'View Report'}
                          </button>
                        </td>
                      </tr>
                    ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* =========================================================================
          BEGINNING INVENTORY SETUP MODAL
          ========================================================================= */}
      {beginningModalOpen && currentBranch && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fadeIn">
          <div className="bg-slate-900 rounded-3xl shadow-2xl max-w-md w-full border border-amber-500/40 overflow-hidden">
            <div className="flex items-center justify-between px-6 py-4 border-b border-amber-500/20 bg-slate-950">
              <div className="flex items-center gap-2">
                <PlusCircle className="w-5 h-5 text-amber-400" />
                <div>
                  <h3 className="text-sm font-bold text-white">
                    {language === 'am' ? 'የቅርንጫፍ መነሻ ክምችት ማስገቢያ' : 'Set Branch Beginning Inventory'}
                  </h3>
                  <span className="text-[10px] text-amber-400 font-medium">
                    {currentBranch.nameAm} ({currentBranch.code})
                  </span>
                </div>
              </div>
              <button
                onClick={() => setBeginningModalOpen(false)}
                className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveBeginningStock} className="p-6 space-y-4">
              {beginningSuccess && (
                <div className="p-3 bg-emerald-950/60 border border-emerald-500/40 rounded-xl flex items-center gap-2 text-emerald-300 text-xs">
                  <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
                  <span>{language === 'am' ? 'የመነሻ ክምችት በተሳካ ሁኔታ ተመዝግቧል!' : 'Beginning inventory saved!'}</span>
                </div>
              )}

              <DatePickerField
                label={language === 'am' ? 'የመነሻ ክምችት ቀን' : 'Beginning Date'}
                value={beginningDate}
                onChange={setBeginningDate}
                required
              />

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  {language === 'am' ? 'ጥሬ ዕቃ ይምረጡ:' : 'Select Item:'}
                </label>
                <select
                  value={beginningItemId}
                  onChange={(e) => setBeginningItemId(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:ring-2 focus:ring-amber-400/40"
                >
                  {items.map((it) => (
                    <option key={it.id} value={it.id}>
                      {language === 'am' ? it.nameAm : it.nameEn} ({it.unitAm})
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">
                    {language === 'am' ? 'የመነሻ መጠን:' : 'Quantity:'} <span className="text-amber-400">*</span>
                  </label>
                  <input
                    type="number"
                    step="any"
                    min="0"
                    required
                    placeholder="100"
                    value={beginningQty}
                    onChange={(e) => setBeginningQty(e.target.value === '' ? '' : parseFloat(e.target.value))}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white font-mono font-bold focus:outline-none focus:ring-2 focus:ring-amber-400/40"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">
                    {language === 'am' ? 'የአንዱ ዋጋ (ብር):' : 'Unit Cost (ETB):'}
                  </label>
                  <input
                    type="number"
                    step="any"
                    placeholder="የነባር ዋጋ"
                    value={beginningCost}
                    onChange={(e) => setBeginningCost(e.target.value === '' ? '' : parseFloat(e.target.value))}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white font-mono focus:outline-none focus:ring-2 focus:ring-amber-400/40"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-4 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setBeginningModalOpen(false)}
                  className="px-4 py-2 text-xs text-slate-400 hover:text-white"
                >
                  {t.common.cancel}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-gradient-to-r from-amber-400 to-yellow-500 hover:from-amber-300 text-slate-950 font-black rounded-xl text-xs shadow-lg shadow-amber-500/25 ring-1 ring-amber-300"
                >
                  {language === 'am' ? 'መነሻ ክምችት መዝግብ' : 'Save Beginning Stock'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
