export type Language = 'am' | 'en';

export type ItemCategory = 
  | 'produce'    // አትክልት እና ፍራፍሬ
  | 'meat'       // ስጋ እና የዶሮ ውጤቶች
  | 'grain'      // እህል እና ዱቄት
  | 'dairy'      // የወተት ውጤቶች
  | 'spices'     // ቅመማ ቅመም
  | 'oil'        // ዘይት እና ቅባት
  | 'beverage'   // መጠጦች
  | 'packaging'  // ማሸጊያዎች
  | 'other';     // ሌሎች

export type UnitType = 'kg' | 'liter' | 'quintal' | 'gram' | 'pcs' | 'pack' | 'bottle';

export interface PriceRecord {
  date: string;
  ethiopianDateStr: string;
  price: number;
  quantity: number;
  supplier: string;
  grnNumber: string;
}

export interface InventoryItem {
  id: string;
  nameAm: string;
  nameEn: string;
  code: string;
  category: ItemCategory;
  unit: UnitType;
  unitAm: string;
  minStockLevel: number;
  currentCentralStock: number;
  weightedAvgCost: number; // በብር (ETB)
  lastPurchasePrice: number; // የመጨረሻ የገበያ ዋጋ
  priceHistory: PriceRecord[];
  description?: string;
}

export interface Branch {
  id: string;
  nameAm: string;
  nameEn: string;
  code: string;
  location: string;
  manager: string;
  phone: string;
}

export type CentralTransactionType = 
  | 'IN_PURCHASE'          // የገባ እቃ (GRN)
  | 'OUT_BRANCH_TRANSFER'  // ለቅርንጫፍ የተላለፈ (SIV)
  | 'OUT_DAMAGE'           // ብክነት / የተበላሸ
  | 'ADJUSTMENT';          // የቆጠራ ማስተካከያ

export interface CentralBinCardEntry {
  id: string;
  itemId: string;
  date: string; // YYYY-MM-DD
  ethiopianDateStr: string;
  refNo: string; // e.g. GRN-010, SIV-025
  type: CentralTransactionType;
  branchId?: string; // Target branch if transfer
  quantityIn: number;
  quantityOut: number;
  unitPrice: number; // Purchase price or cost price
  balance: number;
  supplierOrDestination: string;
  notes: string;
  recordedBy: string;
}

export type BranchTransactionType = 
  | 'BEGINNING_STOCK'    // የመነሻ ክምችት (Beginning Inventory)
  | 'TRANSFER_IN'        // ከማዕከላዊ ስቶር በ SIV የገባ (Store Issue Voucher Receipt)
  | 'CASH_SALE'          // 1. ቀጥታ በገንዘብ የተሸጠ (Direct Cash Sale / Menu Portions)
  | 'MANAGEMENT_USE'     // 2. ማኔጅመንት የተጠቀመው (Management Hospitality / Consumption)
  | 'STAFF_MEAL'         // 3. የስታፍ ምግብ (Staff Meals & Employee Consumption)
  | 'KITCHEN_USAGE'      // ለማእድ ቤት ዝግጅት የወጣ (General Kitchen Preparation)
  | 'DIRECT_SALE'        // በቀጥታ የተሸጠ (Legacy compatibility)
  | 'WASTE_DAMAGE'       // ብክነት ወይም ጉዳት
  | 'RECONCILIATION_ADJ'; // በቆጠራ / በሪኮንሲሌሽን የተስተካከለ

export interface BranchLedgerEntry {
  id: string;
  branchId: string;
  itemId: string;
  date: string; // YYYY-MM-DD
  ethiopianDateStr: string;
  refNo: string; // e.g. BEG-01, SIV-025, SL-01, MGT-01, STF-01
  type: BranchTransactionType;
  quantityIn: number;
  quantityOut: number;
  balance: number;
  unitCost: number;
  totalValue: number; // Cost value
  sellingPrice?: number; // Cash sale price per unit/portion
  cashRevenue?: number; // Total cash revenue collected
  beneficiaryOrGuest?: string; // Who used it (Management / Staff shift / Guest)
  recipeId?: string; // Associated menu dish id
  portionsSold?: number; // Portions sold or consumed
  reasonOrMenu: string;
  recordedBy: string;
}

export interface RecipeIngredient {
  itemId: string;
  quantity: number; // quantity needed per 1 portion (in item's base unit)
  unit?: string;
  isPrepItem?: boolean; // if true, itemId or prepItemId refers to a KitchenPrepItem (e.g. Bolognese Sauce)
  prepItemId?: string;
}

export interface KitchenPrepIngredient {
  itemId: string;
  quantity: number; // raw material needed per base batch yield
  unit?: string;
}

export interface KitchenPrepItem {
  id: string;
  branchId?: string; // specific branch (e.g. Bello for sauces, Coconu/Juice for patties) or undefined/'all'
  nameAm: string;    // e.g. 'ቦሎኛይስ ሶስ', 'ፔስቶ ሶስ', 'ዛፈራኖ ሶስ', 'ቶማቶ ሶስ', 'የበርገር ፓቲ', 'የፒዛ ስጋ'
  nameEn: string;
  category: 'sauce' | 'patty' | 'meat_prep' | 'dressing' | 'bakery' | 'other';
  outputUnit: string; // 'kg' | 'liter' | 'pcs'
  outputUnitAm: string; // 'ኪ.ግ' | 'ሊትር' | 'ፍሬ'
  batchYield: number; // e.g. 1 kg or 10 pcs
  ingredients: KitchenPrepIngredient[];
  preparationNotes?: string;
  isActive: boolean;
}

export interface KitchenPrepBatch {
  id: string;
  branchId: string;
  prepItemId: string;
  prepItemNameAm: string;
  prepItemNameEn: string;
  date: string;
  ethiopianDateStr: string;
  quantityProduced: number;
  outputUnitAm: string;
  totalCostETB: number;
  deductedItems: {
    itemId: string;
    itemNameAm: string;
    quantityDeducted: number;
    unitAm: string;
    unitCost: number;
    subTotalCost: number;
  }[];
  notes?: string;
  recordedBy: string;
  createdAt: string;
}

export interface Recipe {
  id: string;
  branchId: string; // እያንዳንዱ ብራንች የራሱ ሜኑ/ዋጋ/ሪሲፒ አለው (Branch-specific recipe)
  nameAm: string;
  nameEn: string;
  category: string;
  portionDescription: string;
  sellingPrice: number; // የመሸጫ ዋጋ (ETB) - ለዚህ ብራንች የተለየ
  ingredients: RecipeIngredient[];
  preparationNotes?: string;
  isActive: boolean;
}

export interface ScheduleMenuItem {
  recipeId: string;
  portionsPlanned: number;
  portionsSold: number;
}

export interface ProductionSchedule {
  id: string;
  branchId: string;
  date: string; // YYYY-MM-DD
  ethiopianDateStr: string;
  shift: 'morning' | 'lunch' | 'dinner' | 'all_day' | 'catering';
  name: string;
  items: ScheduleMenuItem[];
  notes?: string;
  status: 'planned' | 'in_progress' | 'reconciled';
}

export interface IngredientReconciliationDetail {
  itemId: string;
  itemNameAm: string;
  itemNameEn: string;
  unit: string;
  unitAm: string;
  unitCost: number;
  beginningStock?: number; // የጠዋት ቢግኒንግ ክምችት
  transfersIn?: number;    // በቀኑ ከማዕከላዊ ስቶር የገባ
  totalAvailable?: number; // በቀኑ የነበረ አጠቃላይ ግብአት (Beginning + TransfersIn)
  endingStock?: number;    // የማታ ኢንዲንግ ቆጠራ
  theoreticalRequired: number; // በሪሲፒው መሰረት መውጣት የነበረበት
  physicalActualUsed: number;  // በእጅ የተጠቀሙት እውነተኛ መጠን ((Beginning + In) - Ending)
  variance: number; // Short or Over: Actual - Theoretical
  variancePercent: number;
  financialImpactETB: number; // የገንዘብ ተጽእኖ በብር (Variance * UnitCost)
  status: 'balanced' | 'shortage' | 'excess' | 'critical';
  sharedRecipes: {
    recipeNameAm: string;
    recipeNameEn: string;
    portionSold: number;
    ingredientPerPortion: number;
    subTotalRequired: number;
  }[];
}

export interface KitchenPrepReconciliationDetail {
  prepItemId: string;
  nameAm: string;
  nameEn: string;
  outputUnitAm: string;
  beginningFridgeStock: number; // ጠዋት በፍሪጅ የነበረ የተዘጋጀ ሶስ/ፓቲ
  producedToday: number;        // ዛሬ በባች የተመረተ (+ ከስቶር ጥሬ ዕቃ ተቀንሶ የተዘጋጀ)
  totalAvailable: number;       // ጠቅላላ ዝግጁ ሶስ (Beginning + Produced)
  theoreticalUsed: number;      // በሽያጭ የወጣ (Dishes sold * sauce per portion)
  endingFridgeStock: number;    // ማታ በፍሪጅ የተቆጠረ ቀሪ
  actualUsed: number;           // በእጅ የወጣ ((Beg + Prod) - Ending)
  variance: number;             // Short / Over
  status: 'balanced' | 'shortage' | 'excess';
  usedInDishes: {
    dishNameAm: string;
    portionSold: number;
    saucePerPortion: number;
    totalSauceRequired: number;
  }[];
}

export interface ReconciliationSession {
  id: string;
  branchId: string;
  date: string;
  ethiopianDateStr: string;
  dishesSold: { recipeId: string; quantitySold: number }[]; // የካሽ ሪጅስተር ሽያጭ
  chefDishesProduced?: { recipeId: string; quantityProduced: number }[]; // የሼፎች ማውጫ ኦርደር (KOT)
  managementDishes?: { recipeId: string; quantityConsumed: number }[]; // የማኔጅመንት/የተፈረመበት ምግብ
  details: IngredientReconciliationDetail[];
  prepDetails?: KitchenPrepReconciliationDetail[]; // የተዘጋጁ ሶሶችና ፓቲዎች ሪኮንሲሌሽን
  totalVarianceCostETB: number;
  totalCashRevenueETB?: number;
  totalManagementCostETB?: number;
  status: 'draft' | 'approved';
  approvedBy?: string;
  notes?: string;
  createdAt: string;
}

export interface BranchDailyClosingItemSummary {
  itemId: string;
  itemNameAm: string;
  itemNameEn: string;
  unitAm: string;
  unitCost: number;
  beginningStock: number;
  receivedSIV: number;
  cashSaleQty: number;
  managementQty: number;
  staffMealQty: number;
  damageQty: number;
  totalOutQty: number;
  expectedClosingStock: number;
  actualPhysicalStock: number;
  varianceQty: number;
  varianceCostETB: number;
  status: 'balanced' | 'shortage' | 'excess';
}

export interface BranchDailyClosing {
  id: string;
  branchId: string;
  date: string;
  ethiopianDateStr: string;
  closingNumber: string;
  closedBy: string;
  closedAt: string;
  totalCashSalesETB: number;
  totalManagementCostETB: number;
  totalStaffMealCostETB: number;
  totalMaterialCostETB: number;
  totalVarianceCostETB: number;
  itemSummaries: BranchDailyClosingItemSummary[];
  notes?: string;
  status: 'closed';
}

// ==========================================
// የሰራተኞች ምግብ እና ከሰኞ-አርብ ስኬጁል ኮንትሮሊንግ (Staff Meal & Controlling)
// ==========================================

export interface StaffMealRecipe {
  id: string;
  branchId: string;
  nameAm: string;
  nameEn: string;
  category: 'breakfast' | 'lunch' | 'dinner' | 'general';
  portionUnit: string; // e.g. '1 ሰራተኛ / 1 ሰው'
  ingredients: RecipeIngredient[];
  cookingInstructions: string; // እንዴት እንዴት ማብሰል እንዳለብን (Cooking steps, sequence, heat, tips)
  targetCostPerPerson?: number; // ኢላማ የተደረገ የአንድ ሰራተኛ ወጪ (ETB)
  notes?: string;
  createdAt: string;
}

export interface StaffMember {
  id: string;
  branchId: string;
  fullName: string;       // የሰራተኛው ስም
  employeeNumber: string; // የሰራተኛ ቁጥር (e.g. EMP-001)
  department: string;     // የስራ ክፍል (ለምሳሌ፦ ማእድ ቤት፣ አስተናጋጅ፣ ጥበቃ፣ ጽዳት...)
  isActive: boolean;
}

export type WeekDayKey = 'monday' | 'tuesday' | 'wednesday' | 'thursday' | 'friday' | 'saturday' | 'sunday';

export interface StaffDaySchedule {
  dayKey: WeekDayKey;
  dayNameAm: string; // 'ሰኞ' | 'ማክሰኞ' | 'ረቡዕ' | 'ሐሙስ' | 'አርብ' | 'ቅዳሜ' | 'እሁድ'
  mealType: 'breakfast' | 'lunch' | 'dinner';
  recipeId?: string;
  customMealName?: string;
  headcount: number; // የታቀደ የሰራተኛ ቁጥር
  employeeIds: string[]; // የተመደቡ ሰራተኞች
  cookingNotes?: string; // የማብሰያ ልዩ ማስታወሻ
  status: 'planned' | 'served' | 'skipped';
}

export interface StaffWeeklySchedule {
  id: string;
  branchId: string;
  weekStartDate: string; // Monday date YYYY-MM-DD
  ethiopianDateStr: string;
  scheduleType?: '5_days' | '7_days';
  days: {
    monday: StaffDaySchedule;
    tuesday: StaffDaySchedule;
    wednesday: StaffDaySchedule;
    thursday: StaffDaySchedule;
    friday: StaffDaySchedule;
    saturday?: StaffDaySchedule;
    sunday?: StaffDaySchedule;
  };
  notes?: string;
  status: 'draft' | 'active' | 'completed';
}

export interface StaffMealExecution {
  id: string;
  branchId: string;
  date: string;
  ethiopianDateStr: string;
  dayOfWeek: 'monday' | 'tuesday' | 'wednesday' | 'thursday' | 'friday';
  recipeId: string;
  recipeNameAm: string;
  headcount: number; // የሰራተኞች ቁጥር
  staffNames: string[]; // የሰራተኞች ስም ዝርዝር
  totalCostETB: number; // ጠቅላላ የሰራተኞች ምግብ ወጪ
  costPerPersonETB: number; // የአንድ ሰራተኛ ምግብ ዋጋ (በፐርሰን)
  ingredientDetails: {
    itemId: string;
    itemNameAm: string;
    unitAm: string;
    qtyPerPerson: number; // የአንድ ሰራተኛ ድርሻ
    totalQtyUsed: number; // ለሁሉም ሰራተኞች የወጣው ጠቅላላ
    unitCost: number;
    totalCost: number;
  }[];
  cookingChef?: string;
  notes?: string;
  createdAt: string;
}
