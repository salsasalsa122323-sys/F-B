import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  InventoryItem,
  Branch,
  CentralBinCardEntry,
  BranchLedgerEntry,
  Recipe,
  ProductionSchedule,
  ReconciliationSession,
  IngredientReconciliationDetail,
  BranchDailyClosing,
  BranchTransactionType,
  StaffMealRecipe,
  StaffMember,
  StaffWeeklySchedule,
  StaffMealExecution,
  KitchenPrepItem,
  KitchenPrepBatch,
  KitchenPrepReconciliationDetail,
} from '../types';
import {
  INITIAL_ITEMS,
  INITIAL_BRANCHES,
  INITIAL_CENTRAL_BIN_CARD,
  INITIAL_BRANCH_LEDGERS,
  INITIAL_RECIPES,
  INITIAL_SCHEDULES,
  SAMPLE_ITEMS,
  SAMPLE_BRANCHES,
  SAMPLE_RECIPES,
} from '../data/initialData';
import { INITIAL_PREP_ITEMS } from '../data/initialPrepItems';
import { formatEthiopianDate, getTodayDateString } from '../utils/ethiopianDate';
import {
  saveToPersistentDB,
  getFromPersistentDB,
  downloadDatabaseBackup,
  readDatabaseBackupFile,
  saveBackupSnapshot,
  getAllBackupSnapshots,
  deleteBackupSnapshot,
  BackupSnapshot,
  generateSyncCode,
  parseSyncCode,
  safeLocalStorageSet,
  cleanStaleLocalStorage,
  clearAllPersistentDB,
} from '../utils/persistentStorage';

export interface StockInPayload {
  itemId: string;
  quantity: number;
  unitPrice: number;
  date: string;
  supplier: string;
  grnNumber: string;
  notes?: string;
  recordedBy?: string;
}

export interface TransferPayload {
  itemId: string;
  branchId: string;
  quantity: number;
  date: string;
  sivNumber: string;
  notes?: string;
  recordedBy?: string;
}

export interface BranchUsagePayload {
  branchId: string;
  itemId: string;
  quantity: number;
  date: string;
  type: BranchTransactionType;
  reasonOrMenu: string;
  refNo: string;
  recordedBy?: string;
}

export interface BranchThreeWayUsagePayload {
  branchId: string;
  date: string; // YYYY-MM-DD
  type: 'CASH_SALE' | 'MANAGEMENT_USE' | 'STAFF_MEAL' | 'WASTE_DAMAGE' | 'KITCHEN_USAGE';
  mode: 'recipe' | 'item';
  recipeId?: string;
  portions?: number;
  itemId?: string;
  quantity?: number;
  sellingPrice?: number;
  totalCashRevenue?: number;
  beneficiaryOrGuest?: string; // ማኔጅመንት ስም/እንግዳ ወይም የሰራተኞች ሽፍት
  reasonOrNotes?: string;
  refNo?: string;
  recordedBy?: string;
}

interface AppContextType {
  items: InventoryItem[];
  branches: Branch[];
  centralBinCards: CentralBinCardEntry[];
  branchLedgers: BranchLedgerEntry[];
  recipes: Recipe[];
  schedules: ProductionSchedule[];
  reconciliations: ReconciliationSession[];
  branchDailyClosings: BranchDailyClosing[];
  staffMealRecipes: StaffMealRecipe[];
  staffMembers: StaffMember[];
  staffWeeklySchedules: StaffWeeklySchedule[];
  staffMealExecutions: StaffMealExecution[];
  kitchenPrepItems: KitchenPrepItem[];
  kitchenPrepBatches: KitchenPrepBatch[];
  
  // Actions
  recordStockIn: (payload: StockInPayload) => boolean;
  transferToBranch: (payload: TransferPayload) => { success: boolean; error?: string };
  recordBranchUsage: (payload: BranchUsagePayload) => { success: boolean; error?: string };
  recordBranchThreeWayUsage: (payload: BranchThreeWayUsagePayload) => { success: boolean; error?: string };
  setBeginningStock: (branchId: string, itemId: string, quantity: number, date?: string, unitCost?: number) => boolean;
  closeBranchDailyAccount: (closing: BranchDailyClosing) => boolean;
  deleteBranchDailyClosing: (closingId: string) => void;
  saveRecipe: (recipe: Recipe) => void;
  deleteRecipe: (id: string) => void;
  duplicateRecipeToBranch: (sourceRecipeId: string, targetBranchId: string, customPrice?: number) => Recipe | null;
  saveSchedule: (schedule: ProductionSchedule) => void;
  deleteSchedule: (id: string) => void;
  // Kitchen Prep (Sub-Recipe) actions
  saveKitchenPrepItem: (item: KitchenPrepItem) => void;
  deleteKitchenPrepItem: (id: string) => void;
  recordKitchenPrepProduction: (payload: {
    branchId: string;
    prepItemId: string;
    quantityProduced: number;
    date?: string;
    notes?: string;
  }) => { success: boolean; error?: string; batch?: KitchenPrepBatch };
  deleteKitchenPrepBatch: (id: string) => void;
  // Staff Meal actions
  saveStaffMealRecipe: (recipe: StaffMealRecipe) => void;
  deleteStaffMealRecipe: (id: string) => void;
  saveStaffMember: (member: StaffMember) => void;
  deleteStaffMember: (id: string) => void;
  saveStaffWeeklySchedule: (schedule: StaffWeeklySchedule) => void;
  executeStaffMealAndDeduct: (execution: StaffMealExecution) => { success: boolean; error?: string };
  deleteStaffMealExecution: (id: string) => void;
  addNewBranch: (branch: Branch) => void;
  deleteBranch: (id: string) => void;
  createDefaultThreeBranches: () => void;
  addNewItem: (item: InventoryItem) => void;
  deleteItem: (id: string) => void;
  calculateSmartReconciliation: (
    branchId: string,
    date: string,
    dishesSold: { recipeId: string; quantitySold: number }[],
    physicalUsageMap: Record<string, number>,
    notes?: string,
    chefDishesProduced?: { recipeId: string; quantityProduced: number }[],
    managementDishes?: { recipeId: string; quantityConsumed: number }[],
    beginningStockMap?: Record<string, number>,
    endingStockMap?: Record<string, number>,
    transfersInMap?: Record<string, number>,
    prepEndingFridgeStockMap?: Record<string, number>
  ) => ReconciliationSession;
  commitReconciliationToLedger: (reconciliationId: string) => boolean;
  getBranchStockBalance: (branchId: string, itemId: string) => number;
  clearAllDataCompletely: () => void;
  loadSampleTemplate: () => void;
  exportFullBackup: () => void;
  restoreBackupFromFile: (file: File) => Promise<boolean>;
  createManualSnapshot: (label: string) => Promise<BackupSnapshot | null>;
  loadAllSnapshots: () => Promise<BackupSnapshot[]>;
  restoreSnapshotById: (snapshot: BackupSnapshot) => Promise<boolean>;
  deleteSnapshotById: (id: string) => Promise<boolean>;
  getSyncCode: () => string;
  applySyncCode: (code: string) => Promise<boolean>;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

// Storage key with v4 clean scratch prefix to guarantee completely empty initial state as requested
const STORAGE_PREFIX = 'eth_erp_v4_scratch_';

function safeStorageParse<T>(key: string, fallback: T): T {
  try {
    const saved = localStorage.getItem(key);
    if (!saved || saved === 'undefined' || saved === 'null') return fallback;
    return JSON.parse(saved);
  } catch (err) {
    console.warn(`Failed to parse storage item ${key}:`, err);
    return fallback;
  }
}

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Run cleanup and asynchronously hydrate from IndexedDB on startup
  useEffect(() => {
    cleanStaleLocalStorage();

    let isMounted = true;
    const hydrateFromIndexedDB = async () => {
      try {
        const [
          dbItems,
          dbBranches,
          dbBinCards,
          dbBranchLedgers,
          dbRecipes,
          dbSchedules,
          dbReconciliations,
          dbClosings,
          dbStaffRecipes,
          dbStaffMembers,
          dbStaffSchedules,
          dbStaffExecutions,
          dbKitchenPrepItems,
          dbKitchenPrepBatches,
        ] = await Promise.all([
          getFromPersistentDB<InventoryItem[]>('items'),
          getFromPersistentDB<Branch[]>('branches'),
          getFromPersistentDB<CentralBinCardEntry[]>('centralBinCards'),
          getFromPersistentDB<BranchLedgerEntry[]>('branchLedgers'),
          getFromPersistentDB<Recipe[]>('recipes'),
          getFromPersistentDB<ProductionSchedule[]>('schedules'),
          getFromPersistentDB<ReconciliationSession[]>('reconciliations'),
          getFromPersistentDB<BranchDailyClosing[]>('branchDailyClosings'),
          getFromPersistentDB<StaffMealRecipe[]>('staffMealRecipes'),
          getFromPersistentDB<StaffMember[]>('staffMembers'),
          getFromPersistentDB<StaffWeeklySchedule[]>('staffWeeklySchedules'),
          getFromPersistentDB<StaffMealExecution[]>('staffMealExecutions'),
          getFromPersistentDB<KitchenPrepItem[]>('kitchenPrepItems'),
          getFromPersistentDB<KitchenPrepBatch[]>('kitchenPrepBatches'),
        ]);

        if (!isMounted) return;

        // If IndexedDB has records, hydrate React state smoothly
        if (dbItems && dbItems.length > 0) setItems(dbItems);
        if (dbBranches && dbBranches.length > 0) setBranches(dbBranches);
        if (dbBinCards && dbBinCards.length > 0) setCentralBinCards(dbBinCards);
        if (dbBranchLedgers && dbBranchLedgers.length > 0) setBranchLedgers(dbBranchLedgers);
        if (dbRecipes && dbRecipes.length > 0) setRecipes(dbRecipes);
        if (dbSchedules && dbSchedules.length > 0) setSchedules(dbSchedules);
        if (dbReconciliations && dbReconciliations.length > 0) setReconciliations(dbReconciliations);
        if (dbClosings && dbClosings.length > 0) setBranchDailyClosings(dbClosings);
        if (dbStaffRecipes && dbStaffRecipes.length > 0) setStaffMealRecipes(dbStaffRecipes);
        if (dbStaffMembers && dbStaffMembers.length > 0) setStaffMembers(dbStaffMembers);
        if (dbStaffSchedules && dbStaffSchedules.length > 0) setStaffWeeklySchedules(dbStaffSchedules);
        if (dbStaffExecutions && dbStaffExecutions.length > 0) setStaffMealExecutions(dbStaffExecutions);
        if (dbKitchenPrepItems && dbKitchenPrepItems.length > 0) setKitchenPrepItems(dbKitchenPrepItems);
        if (dbKitchenPrepBatches && dbKitchenPrepBatches.length > 0) setKitchenPrepBatches(dbKitchenPrepBatches);
      } catch (err) {
        console.warn('Hydration from IndexedDB error:', err);
      }
    };

    hydrateFromIndexedDB();
    return () => {
      isMounted = false;
    };
  }, []);

  const [items, setItems] = useState<InventoryItem[]>(() =>
    safeStorageParse(`${STORAGE_PREFIX}items`, INITIAL_ITEMS)
  );

  const [branches, setBranches] = useState<Branch[]>(() =>
    safeStorageParse(`${STORAGE_PREFIX}branches`, INITIAL_BRANCHES)
  );

  const [centralBinCards, setCentralBinCards] = useState<CentralBinCardEntry[]>(() =>
    safeStorageParse(`${STORAGE_PREFIX}bin_cards`, INITIAL_CENTRAL_BIN_CARD)
  );

  const [branchLedgers, setBranchLedgers] = useState<BranchLedgerEntry[]>(() =>
    safeStorageParse(`${STORAGE_PREFIX}branch_ledgers`, INITIAL_BRANCH_LEDGERS)
  );

  const [recipes, setRecipes] = useState<Recipe[]>(() =>
    safeStorageParse(`${STORAGE_PREFIX}recipes`, INITIAL_RECIPES)
  );

  const [schedules, setSchedules] = useState<ProductionSchedule[]>(() =>
    safeStorageParse(`${STORAGE_PREFIX}schedules`, INITIAL_SCHEDULES)
  );

  const [reconciliations, setReconciliations] = useState<ReconciliationSession[]>(() =>
    safeStorageParse(`${STORAGE_PREFIX}reconciliations`, [])
  );

  const [branchDailyClosings, setBranchDailyClosings] = useState<BranchDailyClosing[]>(() =>
    safeStorageParse(`${STORAGE_PREFIX}daily_closings`, [])
  );

  const [staffMealRecipes, setStaffMealRecipes] = useState<StaffMealRecipe[]>(() =>
    safeStorageParse(`${STORAGE_PREFIX}staff_recipes`, [])
  );

  const [staffMembers, setStaffMembers] = useState<StaffMember[]>(() =>
    safeStorageParse(`${STORAGE_PREFIX}staff_members`, [])
  );

  const [staffWeeklySchedules, setStaffWeeklySchedules] = useState<StaffWeeklySchedule[]>(() =>
    safeStorageParse(`${STORAGE_PREFIX}staff_schedules`, [])
  );

  const [staffMealExecutions, setStaffMealExecutions] = useState<StaffMealExecution[]>(() =>
    safeStorageParse(`${STORAGE_PREFIX}staff_executions`, [])
  );

  const [kitchenPrepItems, setKitchenPrepItems] = useState<KitchenPrepItem[]>(() =>
    safeStorageParse(`${STORAGE_PREFIX}kitchen_prep_items`, INITIAL_PREP_ITEMS)
  );

  const [kitchenPrepBatches, setKitchenPrepBatches] = useState<KitchenPrepBatch[]>(() =>
    safeStorageParse(`${STORAGE_PREFIX}kitchen_prep_batches`, [])
  );

  useEffect(() => {
    safeLocalStorageSet(`${STORAGE_PREFIX}kitchen_prep_items`, kitchenPrepItems);
    saveToPersistentDB('kitchenPrepItems', kitchenPrepItems);
  }, [kitchenPrepItems]);

  useEffect(() => {
    safeLocalStorageSet(`${STORAGE_PREFIX}kitchen_prep_batches`, kitchenPrepBatches);
    saveToPersistentDB('kitchenPrepBatches', kitchenPrepBatches);
  }, [kitchenPrepBatches]);

  // Save changes safely to localStorage & high-capacity IndexedDB
  useEffect(() => {
    safeLocalStorageSet(`${STORAGE_PREFIX}items`, items);
    saveToPersistentDB('items', items);
  }, [items]);

  useEffect(() => {
    safeLocalStorageSet(`${STORAGE_PREFIX}branches`, branches);
    saveToPersistentDB('branches', branches);
  }, [branches]);

  useEffect(() => {
    safeLocalStorageSet(`${STORAGE_PREFIX}bin_cards`, centralBinCards);
    saveToPersistentDB('centralBinCards', centralBinCards);
  }, [centralBinCards]);

  useEffect(() => {
    safeLocalStorageSet(`${STORAGE_PREFIX}branch_ledgers`, branchLedgers);
    saveToPersistentDB('branchLedgers', branchLedgers);
  }, [branchLedgers]);

  useEffect(() => {
    safeLocalStorageSet(`${STORAGE_PREFIX}recipes`, recipes);
    saveToPersistentDB('recipes', recipes);
  }, [recipes]);

  useEffect(() => {
    safeLocalStorageSet(`${STORAGE_PREFIX}schedules`, schedules);
    saveToPersistentDB('schedules', schedules);
  }, [schedules]);

  useEffect(() => {
    safeLocalStorageSet(`${STORAGE_PREFIX}reconciliations`, reconciliations);
    saveToPersistentDB('reconciliations', reconciliations);
  }, [reconciliations]);

  useEffect(() => {
    safeLocalStorageSet(`${STORAGE_PREFIX}daily_closings`, branchDailyClosings);
    saveToPersistentDB('branchDailyClosings', branchDailyClosings);
  }, [branchDailyClosings]);

  useEffect(() => {
    safeLocalStorageSet(`${STORAGE_PREFIX}staff_recipes`, staffMealRecipes);
    saveToPersistentDB('staffMealRecipes', staffMealRecipes);
  }, [staffMealRecipes]);

  useEffect(() => {
    safeLocalStorageSet(`${STORAGE_PREFIX}staff_members`, staffMembers);
    saveToPersistentDB('staffMembers', staffMembers);
  }, [staffMembers]);

  useEffect(() => {
    safeLocalStorageSet(`${STORAGE_PREFIX}staff_schedules`, staffWeeklySchedules);
    saveToPersistentDB('staffWeeklySchedules', staffWeeklySchedules);
  }, [staffWeeklySchedules]);

  useEffect(() => {
    safeLocalStorageSet(`${STORAGE_PREFIX}staff_executions`, staffMealExecutions);
    saveToPersistentDB('staffMealExecutions', staffMealExecutions);
  }, [staffMealExecutions]);

  /**
   * Calculate current stock balance of an item at a specific branch
   * Beginning + Transfer In - Cash Sale - Management - Staff Meal - Waste - Kitchen
   */
  const getBranchStockBalance = (branchId: string, itemId: string): number => {
    if (!branchId || !itemId) return 0;
    const entries = branchLedgers.filter(
      (entry) => entry.branchId === branchId && entry.itemId === itemId
    );
    let bal = 0;
    entries.forEach((e) => {
      bal += (e.quantityIn || 0) - (e.quantityOut || 0);
    });
    return Math.max(0, Number(bal.toFixed(4)));
  };

  /**
   * 1. RECORD GOODS RECEIVED IN CENTRAL STORE (GRN / የገባ እቃ)
   * Formula: Weighted Average Cost (WAC) = ((OldQty * OldCost) + (NewQty * NewPrice)) / (OldQty + NewQty)
   */
  const recordStockIn = (payload: StockInPayload): boolean => {
    const targetItem = items.find((i) => i.id === payload.itemId);
    if (!targetItem) return false;

    const oldQty = targetItem.currentCentralStock || 0;
    const oldCost = targetItem.weightedAvgCost || 0;
    const newQty = payload.quantity;
    const newPrice = payload.unitPrice;

    // Real Weighted Average Cost formula
    const totalQty = oldQty + newQty;
    const newWac = totalQty > 0 ? ((oldQty * oldCost) + (newQty * newPrice)) / totalQty : newPrice;

    const ethDate = formatEthiopianDate(payload.date);

    setItems((prev) =>
      prev.map((item) => {
        if (item.id === payload.itemId) {
          const newPriceRecord = {
            date: payload.date,
            ethiopianDateStr: ethDate,
            price: newPrice,
            quantity: newQty,
            supplier: payload.supplier,
            grnNumber: payload.grnNumber,
          };
          return {
            ...item,
            currentCentralStock: totalQty,
            weightedAvgCost: Number(newWac.toFixed(2)),
            lastPurchasePrice: newPrice,
            priceHistory: [newPriceRecord, ...(item.priceHistory || [])],
          };
        }
        return item;
      })
    );

    // Master Bin Card Entry
    const newBinCard: CentralBinCardEntry = {
      id: `bin-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      itemId: payload.itemId,
      date: payload.date,
      ethiopianDateStr: ethDate,
      refNo: payload.grnNumber,
      type: 'IN_PURCHASE',
      quantityIn: newQty,
      quantityOut: 0,
      unitPrice: newPrice,
      balance: totalQty,
      supplierOrDestination: payload.supplier || 'አቅራቢ (Supplier)',
      notes: payload.notes || `በአዲሱ የገበያ ዋጋ (${newPrice} ብር) ገቢ የተደረገ`,
      recordedBy: payload.recordedBy || 'ዋና ስቶር ኪፐር (Store Keeper)',
    };

    setCentralBinCards((prev) => [newBinCard, ...prev]);
    return true;
  };

  /**
   * 2. TRANSFER FROM CENTRAL STORE TO BRANCH (SIV / የወጣ እቃ)
   * Decrements Central Bin Card; Increments Branch Ledger independently.
   */
  const transferToBranch = (payload: TransferPayload): { success: boolean; error?: string } => {
    const targetItem = items.find((i) => i.id === payload.itemId);
    const targetBranch = branches.find((b) => b.id === payload.branchId);

    if (!targetItem) return { success: false, error: 'ዕቃው አልተገኘም (Item not found)' };
    if (!targetBranch) return { success: false, error: 'ቅርንጫፉ አልተገኘም (Branch not found)' };

    if (targetItem.currentCentralStock < payload.quantity) {
      return {
        success: false,
        error: `በቂ የማዕከላዊ ስቶር ክምችት የለም! ያለው: ${targetItem.currentCentralStock} ${targetItem.unitAm}፣ የተጠየቀው: ${payload.quantity} ${targetItem.unitAm}`,
      };
    }

    const ethDate = formatEthiopianDate(payload.date);
    const newCentralStock = targetItem.currentCentralStock - payload.quantity;

    // 1. Decrement Central Item Stock
    setItems((prev) =>
      prev.map((i) => (i.id === payload.itemId ? { ...i, currentCentralStock: newCentralStock } : i))
    );

    // 2. Decrement Central Bin Card
    const newBinCard: CentralBinCardEntry = {
      id: `bin-siv-${Date.now()}`,
      itemId: payload.itemId,
      date: payload.date,
      ethiopianDateStr: ethDate,
      refNo: payload.sivNumber,
      type: 'OUT_BRANCH_TRANSFER',
      branchId: payload.branchId,
      quantityIn: 0,
      quantityOut: payload.quantity,
      unitPrice: targetItem.weightedAvgCost,
      balance: newCentralStock,
      supplierOrDestination: `${targetBranch.nameAm} (${targetBranch.nameEn})`,
      notes: payload.notes || `ወደ ${targetBranch.nameAm} በ SIV የተላለፈ`,
      recordedBy: payload.recordedBy || 'ዋና ስቶር ኪፐር',
    };
    setCentralBinCards((prev) => [newBinCard, ...prev]);

    // 3. Increment Branch Ledger independently
    const currentBranchStock = getBranchStockBalance(payload.branchId, payload.itemId);
    const newBranchBalance = currentBranchStock + payload.quantity;

    const newLedgerEntry: BranchLedgerEntry = {
      id: `bled-tr-${Date.now()}`,
      branchId: payload.branchId,
      itemId: payload.itemId,
      date: payload.date,
      ethiopianDateStr: ethDate,
      refNo: payload.sivNumber,
      type: 'TRANSFER_IN',
      quantityIn: payload.quantity,
      quantityOut: 0,
      balance: newBranchBalance,
      unitCost: targetItem.weightedAvgCost,
      totalValue: Number((payload.quantity * targetItem.weightedAvgCost).toFixed(2)),
      reasonOrMenu: `ከማዕከላዊ ስቶር በ SIV የገባ (SIV: ${payload.sivNumber})`,
      recordedBy: payload.recordedBy || targetBranch.manager,
    };
    setBranchLedgers((prev) => [newLedgerEntry, ...prev]);

    return { success: true };
  };

  /**
   * 3. SET BRANCH BEGINNING INVENTORY (መነሻ ክምችት)
   * Each branch has its own beginning inventory per item.
   */
  const setBeginningStock = (
    branchId: string,
    itemId: string,
    quantity: number,
    date?: string,
    unitCost?: number
  ): boolean => {
    const targetBranch = branches.find((b) => b.id === branchId);
    const targetItem = items.find((i) => i.id === itemId);
    if (!targetBranch || !targetItem) return false;

    const effectiveDate = date || getTodayDateString();
    const ethDate = formatEthiopianDate(effectiveDate);
    const cost = unitCost !== undefined ? unitCost : (targetItem.weightedAvgCost || targetItem.lastPurchasePrice || 0);

    // Look for existing BEGINNING_STOCK entry for this branch and item
    const existingIndex = branchLedgers.findIndex(
      (e) => e.branchId === branchId && e.itemId === itemId && e.type === 'BEGINNING_STOCK'
    );

    if (existingIndex >= 0) {
      setBranchLedgers((prev) => {
        const copy = [...prev];
        copy[existingIndex] = {
          ...copy[existingIndex],
          quantityIn: quantity,
          balance: quantity,
          unitCost: cost,
          totalValue: Number((quantity * cost).toFixed(2)),
          date: effectiveDate,
          ethiopianDateStr: ethDate,
        };
        return copy;
      });
    } else {
      const entry: BranchLedgerEntry = {
        id: `beg-${branchId}-${itemId}-${Date.now()}`,
        branchId,
        itemId,
        date: effectiveDate,
        ethiopianDateStr: ethDate,
        refNo: `BEG-${targetItem.code || Date.now().toString().slice(-4)}`,
        type: 'BEGINNING_STOCK',
        quantityIn: quantity,
        quantityOut: 0,
        balance: quantity,
        unitCost: cost,
        totalValue: Number((quantity * cost).toFixed(2)),
        reasonOrMenu: 'የቅርንጫፍ መነሻ ክምችት (Beginning Inventory)',
        recordedBy: targetBranch.manager || 'የቅርንጫፍ አስተዳዳሪ',
      };
      setBranchLedgers((prev) => [entry, ...prev]);
    }
    return true;
  };

  /**
   * 4. RECORD BRANCH THREE-WAY CONSUMPTION / SALES
   * 1) Direct Cash Sale (ቀጥታ በገንዘብ የተሸጠ)
   * 2) Management Consumption (ማኔጅመንት የተጠቀመው)
   * 3) Staff Meal (የስታፍ ምግብ)
   * Plus Waste/Damage.
   * Supports either menu recipe dish (deducts ingredient proportions) or raw item direct deduction.
   */
  const recordBranchThreeWayUsage = (
    payload: BranchThreeWayUsagePayload
  ): { success: boolean; error?: string } => {
    const targetBranch = branches.find((b) => b.id === payload.branchId);
    if (!targetBranch) return { success: false, error: 'ቅርንጫፉ አልተገኘም' };

    const ethDate = formatEthiopianDate(payload.date);

    // MODE A: MENU RECIPE DISH
    if (payload.mode === 'recipe' && payload.recipeId) {
      const recipe = recipes.find((r) => r.id === payload.recipeId);
      if (!recipe) return { success: false, error: 'የተመረጠው ሪሲፒ/ሜኑ አልተገኘም' };

      const portions = payload.portions || 1;
      if (portions <= 0) return { success: false, error: 'እባክዎ ትክክለኛ የፖርሽን መጠን ያስገቡ' };

      // Validate stock availability for all ingredients
      for (const ing of recipe.ingredients) {
        const item = items.find((i) => i.id === ing.itemId);
        const requiredQty = Number((ing.quantity * portions).toFixed(4));
        const currentBal = getBranchStockBalance(payload.branchId, ing.itemId);
        if (currentBal < requiredQty) {
          const itemName = item ? item.nameAm : ing.itemId;
          const unit = item ? item.unitAm : '';
          return {
            success: false,
            error: `ለ${recipe.nameAm} የሚያስፈልገው "${itemName}" በቂ ክምችት የለም! ያለው: ${currentBal} ${unit}፣ የሚያስፈልገው: ${requiredQty} ${unit}`,
          };
        }
      }

      // Compute sales revenue if cash sale
      const unitPrice = payload.sellingPrice !== undefined ? payload.sellingPrice : recipe.sellingPrice;
      const totalCash = payload.totalCashRevenue !== undefined ? payload.totalCashRevenue : portions * unitPrice;

      const newEntries: BranchLedgerEntry[] = [];
      const timestamp = Date.now();

      recipe.ingredients.forEach((ing, index) => {
        const item = items.find((i) => i.id === ing.itemId);
        const requiredQty = Number((ing.quantity * portions).toFixed(4));
        const currentBal = getBranchStockBalance(payload.branchId, ing.itemId);
        const newBal = Number((currentBal - requiredQty).toFixed(4));
        const cost = item ? (item.weightedAvgCost || item.lastPurchasePrice || 0) : 0;

        let channelName = 'ቀጥታ ሽያጭ';
        if (payload.type === 'MANAGEMENT_USE') channelName = 'የማኔጅመንት አጠቃቀም';
        else if (payload.type === 'STAFF_MEAL') channelName = 'የስታፍ ምግብ';
        else if (payload.type === 'WASTE_DAMAGE') channelName = 'ብክነት';

        const entry: BranchLedgerEntry = {
          id: `bled-${payload.type.toLowerCase()}-${timestamp}-${index}`,
          branchId: payload.branchId,
          itemId: ing.itemId,
          date: payload.date,
          ethiopianDateStr: ethDate,
          refNo: payload.refNo || `${payload.type.slice(0, 3)}-${timestamp.toString().slice(-4)}`,
          type: payload.type,
          quantityIn: 0,
          quantityOut: requiredQty,
          balance: newBal,
          unitCost: cost,
          totalValue: Number((requiredQty * cost).toFixed(2)),
          sellingPrice: index === 0 ? unitPrice : undefined,
          cashRevenue: index === 0 && payload.type === 'CASH_SALE' ? totalCash : undefined,
          beneficiaryOrGuest: payload.beneficiaryOrGuest,
          recipeId: recipe.id,
          portionsSold: portions,
          reasonOrMenu: `${recipe.nameAm} (${portions} ፖርሽን) [${channelName}]${payload.reasonOrNotes ? ` - ${payload.reasonOrNotes}` : ''}`,
          recordedBy: payload.recordedBy || targetBranch.manager,
        };
        newEntries.push(entry);
      });

      setBranchLedgers((prev) => [...newEntries, ...prev]);
      return { success: true };
    }

    // MODE B: DIRECT RAW / PACKAGED ITEM
    if (payload.mode === 'item' && payload.itemId) {
      const targetItem = items.find((i) => i.id === payload.itemId);
      if (!targetItem) return { success: false, error: 'ዕቃው አልተገኘም' };

      const qty = payload.quantity || 0;
      if (qty <= 0) return { success: false, error: 'እባክዎ ትክክለኛ መጠን ያስገቡ' };

      const currentBranchStock = getBranchStockBalance(payload.branchId, payload.itemId);
      if (currentBranchStock < qty) {
        return {
          success: false,
          error: `በቂ የቅርንጫፍ ክምችት የለም! በቅርንጫፉ ያለው: ${currentBranchStock} ${targetItem.unitAm}፣ የተጠየቀው: ${qty} ${targetItem.unitAm}`,
        };
      }

      const newBranchBalance = Number((currentBranchStock - qty).toFixed(4));
      const cost = targetItem.weightedAvgCost || targetItem.lastPurchasePrice || 0;
      const unitPrice = payload.sellingPrice || 0;
      const totalCash = payload.totalCashRevenue !== undefined ? payload.totalCashRevenue : (qty * unitPrice);

      let channelName = 'ቀጥታ ሽያጭ';
      if (payload.type === 'MANAGEMENT_USE') channelName = 'የማኔጅመንት አጠቃቀም';
      else if (payload.type === 'STAFF_MEAL') channelName = 'የስታፍ ምግብ';
      else if (payload.type === 'WASTE_DAMAGE') channelName = 'ብክነት';

      const newLedgerEntry: BranchLedgerEntry = {
        id: `bled-${payload.type.toLowerCase()}-${Date.now()}`,
        branchId: payload.branchId,
        itemId: payload.itemId,
        date: payload.date,
        ethiopianDateStr: ethDate,
        refNo: payload.refNo || `${payload.type.slice(0, 3)}-${Date.now().toString().slice(-4)}`,
        type: payload.type,
        quantityIn: 0,
        quantityOut: qty,
        balance: newBranchBalance,
        unitCost: cost,
        totalValue: Number((qty * cost).toFixed(2)),
        sellingPrice: unitPrice > 0 ? unitPrice : undefined,
        cashRevenue: payload.type === 'CASH_SALE' ? totalCash : undefined,
        beneficiaryOrGuest: payload.beneficiaryOrGuest,
        reasonOrMenu: `${targetItem.nameAm} [${channelName}]${payload.reasonOrNotes ? ` - ${payload.reasonOrNotes}` : ''}`,
        recordedBy: payload.recordedBy || targetBranch.manager,
      };

      setBranchLedgers((prev) => [newLedgerEntry, ...prev]);
      return { success: true };
    }

    return { success: false, error: 'ያልተሟላ የመረጃ ጥያቄ' };
  };

  /**
   * Compatibility wrapper for existing legacy branch usage
   */
  const recordBranchUsage = (payload: BranchUsagePayload): { success: boolean; error?: string } => {
    return recordBranchThreeWayUsage({
      branchId: payload.branchId,
      date: payload.date,
      type: payload.type === 'DIRECT_SALE' ? 'CASH_SALE' : (payload.type as any),
      mode: 'item',
      itemId: payload.itemId,
      quantity: payload.quantity,
      reasonOrNotes: payload.reasonOrMenu,
      refNo: payload.refNo,
      recordedBy: payload.recordedBy,
    });
  };

  /**
   * 5. BRANCH DAILY/PERIODIC ACCOUNT & INVENTORY CLOSING (የዕለት ሂሳብ መዝጊያ)
   */
  const closeBranchDailyAccount = (closing: BranchDailyClosing): boolean => {
    setBranchDailyClosings((prev) => {
      const idx = prev.findIndex((c) => c.id === closing.id || (c.branchId === closing.branchId && c.date === closing.date));
      if (idx >= 0) {
        const copy = [...prev];
        copy[idx] = closing;
        return copy;
      }
      return [closing, ...prev];
    });

    // Record any physical variance adjustment to branch ledgers if not zero
    closing.itemSummaries.forEach((summary) => {
      if (summary.varianceQty !== 0) {
        const currentBal = getBranchStockBalance(closing.branchId, summary.itemId);
        const adjEntry: BranchLedgerEntry = {
          id: `bled-adj-${closing.id}-${summary.itemId}`,
          branchId: closing.branchId,
          itemId: summary.itemId,
          date: closing.date,
          ethiopianDateStr: closing.ethiopianDateStr,
          refNo: `CLOSE-ADJ-${closing.closingNumber}`,
          type: 'RECONCILIATION_ADJ',
          quantityIn: summary.varianceQty < 0 ? Math.abs(summary.varianceQty) : 0,
          quantityOut: summary.varianceQty > 0 ? summary.varianceQty : 0,
          balance: summary.actualPhysicalStock,
          unitCost: summary.unitCost,
          totalValue: Math.abs(summary.varianceCostETB),
          reasonOrMenu: `የዕለት ሂሳብ መዝጊያ ቆጠራ ማስተካከያ (ልዩነት: ${summary.varianceQty} ${summary.unitAm})`,
          recordedBy: closing.closedBy,
        };
        setBranchLedgers((prev) => [adjEntry, ...prev]);
      }
    });

    return true;
  };

  const deleteBranchDailyClosing = (closingId: string) => {
    setBranchDailyClosings((prev) => prev.filter((c) => c.id !== closingId));
  };

  /**
   * 6. RECIPE MANAGEMENT - BRANCH SPECIFIC
   */
  const saveRecipe = (recipe: Recipe) => {
    setRecipes((prev) => {
      const idx = prev.findIndex((r) => r.id === recipe.id);
      if (idx >= 0) {
        const updated = [...prev];
        updated[idx] = recipe;
        return updated;
      }
      return [recipe, ...prev];
    });
  };

  const deleteRecipe = (id: string) => {
    setRecipes((prev) => prev.filter((r) => r.id !== id));
  };

  /**
   * Clone a recipe to another branch with customized price or portions
   */
  const duplicateRecipeToBranch = (
    sourceRecipeId: string,
    targetBranchId: string,
    customPrice?: number
  ): Recipe | null => {
    const source = recipes.find((r) => r.id === sourceRecipeId);
    if (!source) return null;

    const newRecipe: Recipe = {
      ...source,
      id: `rec-${targetBranchId}-${Date.now().toString().slice(-4)}`,
      branchId: targetBranchId,
      sellingPrice: customPrice !== undefined ? customPrice : source.sellingPrice,
      isActive: true,
    };

    saveRecipe(newRecipe);
    return newRecipe;
  };

  /**
   * 7. SCHEDULES & PRODUCTION
   */
  const saveSchedule = (schedule: ProductionSchedule) => {
    setSchedules((prev) => {
      const idx = prev.findIndex((s) => s.id === schedule.id);
      if (idx >= 0) {
        const updated = [...prev];
        updated[idx] = schedule;
        return updated;
      }
      return [schedule, ...prev];
    });
  };

  const deleteSchedule = (id: string) => {
    setSchedules((prev) => prev.filter((s) => s.id !== id));
  };

  /**
   * 7.5 STAFF MEALS & CONTROLLING (ከሰኞ እስከ አርብ እና በፐርሰን የሚሰራ ኮንትሮሊንግ)
   */
  const saveStaffMealRecipe = (recipe: StaffMealRecipe) => {
    setStaffMealRecipes((prev) => {
      const idx = prev.findIndex((r) => r.id === recipe.id);
      if (idx >= 0) {
        const updated = [...prev];
        updated[idx] = recipe;
        return updated;
      }
      return [recipe, ...prev];
    });
  };

  const deleteStaffMealRecipe = (id: string) => {
    setStaffMealRecipes((prev) => prev.filter((r) => r.id !== id));
  };

  const saveStaffMember = (member: StaffMember) => {
    setStaffMembers((prev) => {
      const idx = prev.findIndex((m) => m.id === member.id);
      if (idx >= 0) {
        const updated = [...prev];
        updated[idx] = member;
        return updated;
      }
      return [member, ...prev];
    });
  };

  const deleteStaffMember = (id: string) => {
    setStaffMembers((prev) => prev.filter((m) => m.id !== id));
  };

  const saveStaffWeeklySchedule = (schedule: StaffWeeklySchedule) => {
    setStaffWeeklySchedules((prev) => {
      const idx = prev.findIndex(
        (s) =>
          s.id === schedule.id ||
          (s.branchId === schedule.branchId && s.weekStartDate === schedule.weekStartDate)
      );
      if (idx >= 0) {
        const updated = [...prev];
        updated[idx] = schedule;
        return updated;
      }
      return [schedule, ...prev];
    });
  };

  const executeStaffMealAndDeduct = (
    execution: StaffMealExecution
  ): { success: boolean; error?: string } => {
    if (!execution.branchId || !execution.recipeId || execution.headcount <= 0) {
      return {
        success: false,
        error:
          'ቅርንጫፍ፣ የሰራተኞች ሪሲፒ እና ትክክለኛ የሰራተኛ ቁጥር መመረጥ አለበት (Branch, recipe, and headcount required).',
      };
    }

    // Create branch ledger entries for each consumed ingredient
    const newLedgerEntries: BranchLedgerEntry[] = [];
    execution.ingredientDetails.forEach((ing) => {
      if (ing.totalQtyUsed <= 0) return;
      const curBal = getBranchStockBalance(execution.branchId, ing.itemId);
      const newBal = curBal - ing.totalQtyUsed;

      const entry: BranchLedgerEntry = {
        id: `bled-stf-${execution.id}-${ing.itemId}-${Math.random().toString(36).substring(2, 6)}`,
        branchId: execution.branchId,
        itemId: ing.itemId,
        date: execution.date,
        ethiopianDateStr: execution.ethiopianDateStr,
        refNo: `STF-${execution.id.slice(-6)}`,
        type: 'STAFF_MEAL',
        quantityIn: 0,
        quantityOut: ing.totalQtyUsed,
        balance: newBal,
        unitCost: ing.unitCost,
        totalValue: Number(ing.totalCost.toFixed(2)),
        sellingPrice: 0,
        cashRevenue: 0,
        beneficiaryOrGuest: `${execution.headcount} ሰራተኞች: ${execution.staffNames.slice(0, 3).join(', ')}${
          execution.staffNames.length > 3 ? ` ወዘተ (${execution.headcount} ሰው)` : ''
        }`,
        recipeId: execution.recipeId,
        portionsSold: execution.headcount,
        reasonOrMenu: `የሰራተኞች ምግብ: ${execution.recipeNameAm} (${execution.headcount} ሰራተኛ - በፐርሰን ${execution.costPerPersonETB.toFixed(2)} ብር)`,
        recordedBy: execution.cookingChef || 'የወጥ ቤት ሃላፊ / Staff Kitchen Chef',
      };
      newLedgerEntries.push(entry);
    });

    setBranchLedgers((prev) => [...newLedgerEntries, ...prev]);
    setStaffMealExecutions((prev) => [execution, ...prev]);
    return { success: true };
  };

  const deleteStaffMealExecution = (id: string) => {
    setStaffMealExecutions((prev) => prev.filter((e) => e.id !== id));
  };

  /**
   * 7.8 KITCHEN PREP (SUB-RECIPES) & BATCH PRODUCTION
   * ቦሎኛይስ ሶስ፣ ፔስቶ ሶስ፣ ዛፈራኖ፣ ቶማቶ ሶስ፣ የበርገር ፓቲ እና የፒዛ ስጋ ዝግጅት
   */
  const saveKitchenPrepItem = (item: KitchenPrepItem) => {
    setKitchenPrepItems((prev) => {
      const idx = prev.findIndex((p) => p.id === item.id);
      if (idx >= 0) {
        const updated = [...prev];
        updated[idx] = item;
        return updated;
      }
      return [item, ...prev];
    });
  };

  const deleteKitchenPrepItem = (id: string) => {
    setKitchenPrepItems((prev) => prev.filter((p) => p.id !== id));
  };

  const recordKitchenPrepProduction = (payload: {
    branchId: string;
    prepItemId: string;
    quantityProduced: number;
    date?: string;
    notes?: string;
  }): { success: boolean; error?: string; batch?: KitchenPrepBatch } => {
    const { branchId, prepItemId, quantityProduced, notes } = payload;
    const date = payload.date || getTodayDateString();
    const ethDate = formatEthiopianDate(date);

    if (!branchId || !prepItemId || quantityProduced <= 0) {
      return { success: false, error: 'ትክክለኛ ቅርንጫፍ፣ የዝግጅት እቃ እና የተመረተ መጠን ያስፈልጋል' };
    }

    const prepItem = kitchenPrepItems.find((p) => p.id === prepItemId);
    if (!prepItem) {
      return { success: false, error: 'የተመረጠው የቅድመ-ዝግጅት ሪሲፒ አልተገኘም' };
    }

    const ratio = quantityProduced / (prepItem.batchYield || 1);
    const newLedgerEntries: BranchLedgerEntry[] = [];
    const deductedItems: {
      itemId: string;
      itemNameAm: string;
      quantityDeducted: number;
      unitAm: string;
      unitCost: number;
      subTotalCost: number;
    }[] = [];

    let totalCostETB = 0;

    prepItem.ingredients.forEach((ing) => {
      const item = items.find((i) => i.id === ing.itemId);
      if (!item) return;

      const rawNeeded = Number((ing.quantity * ratio).toFixed(3));
      const curBal = getBranchStockBalance(branchId, ing.itemId);
      const newBal = Number((curBal - rawNeeded).toFixed(3));
      const unitCost = item.weightedAvgCost || item.lastPurchasePrice || 1;
      const subTotal = Number((rawNeeded * unitCost).toFixed(2));
      totalCostETB += subTotal;

      const entry: BranchLedgerEntry = {
        id: `bled-prep-${Date.now()}-${ing.itemId}-${Math.random().toString(36).substring(2, 5)}`,
        branchId,
        itemId: ing.itemId,
        date,
        ethiopianDateStr: ethDate,
        refNo: `PREP-${Date.now().toString().slice(-4)}`,
        type: 'KITCHEN_USAGE',
        quantityIn: 0,
        quantityOut: rawNeeded,
        balance: newBal,
        unitCost,
        totalValue: subTotal,
        sellingPrice: 0,
        cashRevenue: 0,
        reasonOrMenu: `ለ${prepItem.nameAm} ዝግጅት የወጣ (${quantityProduced} ${prepItem.outputUnitAm})`,
        recordedBy: 'የኩሽና ቁጥጥር / Kitchen Prep Control',
      };
      newLedgerEntries.push(entry);

      deductedItems.push({
        itemId: ing.itemId,
        itemNameAm: item.nameAm,
        quantityDeducted: rawNeeded,
        unitAm: item.unitAm,
        unitCost,
        subTotalCost: subTotal,
      });
    });

    const batch: KitchenPrepBatch = {
      id: `prep-batch-${Date.now()}`,
      branchId,
      prepItemId,
      prepItemNameAm: prepItem.nameAm,
      prepItemNameEn: prepItem.nameEn,
      date,
      ethiopianDateStr: ethDate,
      quantityProduced,
      outputUnitAm: prepItem.outputUnitAm,
      totalCostETB: Number(totalCostETB.toFixed(2)),
      deductedItems,
      notes,
      recordedBy: 'ስራ አስኪያጅ / Owner Control',
      createdAt: new Date().toISOString(),
    };

    setBranchLedgers((prev) => [...newLedgerEntries, ...prev]);
    setKitchenPrepBatches((prev) => [batch, ...prev]);

    return { success: true, batch };
  };

  const deleteKitchenPrepBatch = (id: string) => {
    setKitchenPrepBatches((prev) => prev.filter((b) => b.id !== id));
  };

  /**
   * 8. BRANCH & ITEM MASTERS
   */
  const addNewBranch = (branch: Branch) => {
    setBranches((prev) => [...prev, branch]);
  };

  const deleteBranch = (id: string) => {
    setBranches((prev) => prev.filter((b) => b.id !== id));
  };

  const createDefaultThreeBranches = () => {
    const defaultBranches: Branch[] = [
      {
        id: 'br-bole',
        code: 'BR-BOL-01',
        nameAm: 'ቦሌ ቅርንጫፍ',
        nameEn: 'Bole Branch',
        location: 'ቦሌ መድኃኔዓለም ፊት ለፊት',
        manager: 'አቶ ዳዊት ከበደ',
        phone: '+251 911 234 567',
      },
      {
        id: 'br-piassa',
        code: 'BR-PIA-02',
        nameAm: 'ፒያሳ ቅርንጫፍ',
        nameEn: 'Piassa Branch',
        location: 'ቸርችል ጎዳና፣ ቴዎድሮስ አደባባይ',
        manager: 'ወ/ሮ ትዕግስት ኃይሉ',
        phone: '+251 911 345 678',
      },
      {
        id: 'br-cmc',
        code: 'BR-CMC-03',
        nameAm: 'ሲኤምሲ ቅርንጫፍ',
        nameEn: 'CMC Branch',
        location: 'ሲኤምሲ ሚካኤል አደባባይ',
        manager: 'አቶ ዮናስ ታደሰ',
        phone: '+251 911 456 789',
      },
    ];
    setBranches(defaultBranches);
  };

  const addNewItem = (item: InventoryItem) => {
    setItems((prev) => [...prev, item]);
  };

  const deleteItem = (id: string) => {
    setItems((prev) => prev.filter((i) => i.id !== id));
  };

  /**
   * 9. SMART RECONCILIATION ENGINE
   */
  const calculateSmartReconciliation = (
    branchId: string,
    date: string,
    dishesSold: { recipeId: string; quantitySold: number }[],
    physicalUsageMap: Record<string, number>,
    notes?: string,
    chefDishesProduced: { recipeId: string; quantityProduced: number }[] = [],
    managementDishes: { recipeId: string; quantityConsumed: number }[] = [],
    beginningStockMap: Record<string, number> = {},
    endingStockMap: Record<string, number> = {},
    transfersInMap: Record<string, number> = {},
    prepEndingFridgeStockMap: Record<string, number> = {}
  ): ReconciliationSession => {
    const ethDate = formatEthiopianDate(date);
    const ingredientAggregation: Record<
      string,
      {
        totalTheoretical: number;
        sharedDishes: {
          recipeNameAm: string;
          recipeNameEn: string;
          portionSold: number;
          ingredientPerPortion: number;
          subTotalRequired: number;
        }[];
      }
    > = {};

    // 1. Calculate from Cash Register Sales
    dishesSold.forEach((dish) => {
      if (dish.quantitySold <= 0) return;
      const recipe = recipes.find((r) => r.id === dish.recipeId);
      if (!recipe) return;

      recipe.ingredients.forEach((ing) => {
        if (!ingredientAggregation[ing.itemId]) {
          ingredientAggregation[ing.itemId] = {
            totalTheoretical: 0,
            sharedDishes: [],
          };
        }
        const needed = dish.quantitySold * ing.quantity;
        ingredientAggregation[ing.itemId].totalTheoretical += needed;
        ingredientAggregation[ing.itemId].sharedDishes.push({
          recipeNameAm: `${recipe.nameAm} (ሽያጭ)`,
          recipeNameEn: `${recipe.nameEn} (Cash Sale)`,
          portionSold: dish.quantitySold,
          ingredientPerPortion: ing.quantity,
          subTotalRequired: Number(needed.toFixed(3)),
        });
      });
    });

    // 2. Calculate from Management / Signed Meals
    managementDishes.forEach((dish) => {
      if (dish.quantityConsumed <= 0) return;
      const recipe = recipes.find((r) => r.id === dish.recipeId);
      if (!recipe) return;

      recipe.ingredients.forEach((ing) => {
        if (!ingredientAggregation[ing.itemId]) {
          ingredientAggregation[ing.itemId] = {
            totalTheoretical: 0,
            sharedDishes: [],
          };
        }
        const needed = dish.quantityConsumed * ing.quantity;
        ingredientAggregation[ing.itemId].totalTheoretical += needed;
        ingredientAggregation[ing.itemId].sharedDishes.push({
          recipeNameAm: `${recipe.nameAm} (ማኔጅመንት)`,
          recipeNameEn: `${recipe.nameEn} (Management)`,
          portionSold: dish.quantityConsumed,
          ingredientPerPortion: ing.quantity,
          subTotalRequired: Number(needed.toFixed(3)),
        });
      });
    });

    const details: IngredientReconciliationDetail[] = [];
    let totalVarianceCostETB = 0;

    const allItemIds = new Set([
      ...Object.keys(ingredientAggregation),
      ...Object.keys(beginningStockMap),
      ...Object.keys(endingStockMap),
      ...Object.keys(physicalUsageMap),
    ]);

    allItemIds.forEach((itemId) => {
      const item = items.find((i) => i.id === itemId);
      if (!item) return;

      const agg = ingredientAggregation[itemId] || { totalTheoretical: 0, sharedDishes: [] };
      const theoretical = Number(agg.totalTheoretical.toFixed(3));

      const beg = beginningStockMap[itemId] !== undefined ? beginningStockMap[itemId] : getBranchStockBalance(branchId, itemId);
      const trans = transfersInMap[itemId] !== undefined ? transfersInMap[itemId] : 0;
      const totalAvail = Number((beg + trans).toFixed(3));
      
      const ending = endingStockMap[itemId] !== undefined ? endingStockMap[itemId] : 0;
      
      // Calculate actual physical consumption: (Beginning + In) - Ending
      let actual = 0;
      if (physicalUsageMap[itemId] !== undefined) {
        actual = physicalUsageMap[itemId];
      } else if (endingStockMap[itemId] !== undefined) {
        actual = Math.max(0, Number((totalAvail - ending).toFixed(3)));
      } else {
        actual = theoretical;
      }

      const variance = Number((actual - theoretical).toFixed(3));
      const variancePercent = theoretical > 0 ? Number(((variance / theoretical) * 100).toFixed(1)) : 0;
      const costPerUnit = item.weightedAvgCost || item.lastPurchasePrice || 1;
      const financialImpact = Number((variance * costPerUnit).toFixed(2));
      totalVarianceCostETB += financialImpact;

      let status: 'balanced' | 'shortage' | 'excess' | 'critical' = 'balanced';
      if (variance > 0.005) {
        status = variancePercent > 15 ? 'critical' : 'shortage';
      } else if (variance < -0.005) {
        status = 'excess';
      }

      details.push({
        itemId,
        itemNameAm: item.nameAm,
        itemNameEn: item.nameEn,
        unit: item.unit,
        unitAm: item.unitAm,
        unitCost: costPerUnit,
        beginningStock: beg,
        transfersIn: trans,
        totalAvailable: totalAvail,
        endingStock: ending,
        theoreticalRequired: theoretical,
        physicalActualUsed: actual,
        variance,
        variancePercent,
        financialImpactETB: financialImpact,
        status,
        sharedRecipes: agg.sharedDishes,
      });
    });

    const totalCashRevenueETB = dishesSold.reduce((acc, d) => {
      const r = recipes.find((x) => x.id === d.recipeId);
      return acc + (d.quantitySold * (r?.sellingPrice || 0));
    }, 0);

    const totalManagementCostETB = (managementDishes || []).reduce((acc, d) => {
      const r = recipes.find((x) => x.id === d.recipeId);
      return acc + (d.quantityConsumed * (r?.sellingPrice || 0));
    }, 0);

    // 3. Calculate Kitchen Prep Reconciliations (የተዘጋጁ ሶሶችና ፓቲዎች ቆጠራ እና ሪኮንሲሌሽን)
    const prepDetails: KitchenPrepReconciliationDetail[] = [];
    const activePrepItems = kitchenPrepItems.filter(
      (p) => !p.branchId || p.branchId === 'all' || p.branchId === branchId
    );

    activePrepItems.forEach((prep) => {
      const producedToday = kitchenPrepBatches
        .filter((b) => b.branchId === branchId && b.date === date && b.prepItemId === prep.id)
        .reduce((sum, b) => sum + b.quantityProduced, 0);

      let theoreticalUsed = 0;
      const usedInDishes: {
        dishNameAm: string;
        portionSold: number;
        saucePerPortion: number;
        totalSauceRequired: number;
      }[] = [];

      const allDishes = [
        ...dishesSold.map((d) => ({ recipeId: d.recipeId, qty: d.quantitySold, type: 'ሽያጭ' })),
        ...(managementDishes || []).map((d) => ({ recipeId: d.recipeId, qty: d.quantityConsumed, type: 'ማኔጅመንት' })),
      ];

      allDishes.forEach(({ recipeId, qty, type }) => {
        if (qty <= 0) return;
        const recipe = recipes.find((r) => r.id === recipeId);
        if (!recipe) return;

        recipe.ingredients.forEach((ing) => {
          if (
            (ing.isPrepItem && (ing.itemId === prep.id || ing.prepItemId === prep.id)) ||
            ing.itemId === prep.id
          ) {
            const req = Number((qty * ing.quantity).toFixed(3));
            theoreticalUsed += req;
            usedInDishes.push({
              dishNameAm: `${recipe.nameAm} (${type})`,
              portionSold: qty,
              saucePerPortion: ing.quantity,
              totalSauceRequired: req,
            });
          }
        });
      });

      const beginningFridgeStock = 0;
      const totalAvailable = Number((beginningFridgeStock + producedToday).toFixed(3));
      const endingFridgeStock = prepEndingFridgeStockMap && prepEndingFridgeStockMap[prep.id] !== undefined
        ? prepEndingFridgeStockMap[prep.id]
        : Math.max(0, Number((totalAvailable - theoreticalUsed).toFixed(3)));

      const actualUsed = Math.max(0, Number((totalAvailable - endingFridgeStock).toFixed(3)));
      const variance = Number((actualUsed - theoreticalUsed).toFixed(3));

      let status: 'balanced' | 'shortage' | 'excess' = 'balanced';
      if (variance > 0.01) {
        status = 'shortage';
      } else if (variance < -0.01) {
        status = 'excess';
      }

      if (producedToday > 0 || theoreticalUsed > 0 || endingFridgeStock > 0 || prep.isActive) {
        prepDetails.push({
          prepItemId: prep.id,
          nameAm: prep.nameAm,
          nameEn: prep.nameEn,
          outputUnitAm: prep.outputUnitAm,
          beginningFridgeStock,
          producedToday,
          totalAvailable,
          theoreticalUsed: Number(theoreticalUsed.toFixed(3)),
          endingFridgeStock,
          actualUsed,
          variance,
          status,
          usedInDishes,
        });
      }
    });

    const session: ReconciliationSession = {
      id: `rec-sess-${Date.now()}`,
      branchId,
      date,
      ethiopianDateStr: ethDate,
      dishesSold,
      chefDishesProduced,
      managementDishes,
      details,
      prepDetails,
      totalVarianceCostETB: Number(totalVarianceCostETB.toFixed(2)),
      totalCashRevenueETB: Number(totalCashRevenueETB.toFixed(2)),
      totalManagementCostETB: Number(totalManagementCostETB.toFixed(2)),
      status: 'draft',
      notes,
      createdAt: new Date().toISOString(),
    };

    setReconciliations((prev) => [session, ...prev]);
    return session;
  };

  const commitReconciliationToLedger = (reconciliationId: string): boolean => {
    const session = reconciliations.find((s) => s.id === reconciliationId);
    if (!session) return false;

    session.details.forEach((detail) => {
      const curBal = getBranchStockBalance(session.branchId, detail.itemId);
      const newBal = curBal - detail.physicalActualUsed;

      const ledgerEntry: BranchLedgerEntry = {
        id: `bled-rec-${session.id}-${detail.itemId}`,
        branchId: session.branchId,
        itemId: detail.itemId,
        date: session.date,
        ethiopianDateStr: session.ethiopianDateStr,
        refNo: `REC-ADJ-${session.id.slice(-4)}`,
        type: 'RECONCILIATION_ADJ',
        quantityIn: 0,
        quantityOut: detail.physicalActualUsed,
        balance: newBal,
        unitCost: detail.unitCost,
        totalValue: Number((detail.physicalActualUsed * detail.unitCost).toFixed(2)),
        reasonOrMenu: `ስማርት ሪኮንሲሌሽን: የተሰላ ${detail.theoreticalRequired}${detail.unitAm}፣ የወጣ ${detail.physicalActualUsed}${detail.unitAm} (ልዩነት: ${detail.variance}${detail.unitAm})`,
        recordedBy: 'የቅርንጫፍ ተቆጣጣሪ (Reconciliation Auditor)',
      };

      setBranchLedgers((prev) => [ledgerEntry, ...prev]);
    });

    setReconciliations((prev) =>
      prev.map((s) => (s.id === reconciliationId ? { ...s, status: 'approved' } : s))
    );

    return true;
  };

  // Full clean wipe function
  const clearAllDataCompletely = () => {
    setItems([]);
    setBranches([]);
    setCentralBinCards([]);
    setBranchLedgers([]);
    setRecipes([]);
    setSchedules([]);
    setReconciliations([]);
    setBranchDailyClosings([]);
    setStaffMealRecipes([]);
    setStaffMembers([]);
    setStaffWeeklySchedules([]);
    setStaffMealExecutions([]);
    setKitchenPrepItems([]);
    setKitchenPrepBatches([]);

    try {
      Object.keys(localStorage).forEach((key) => {
        if (key.startsWith('eth_erp_')) {
          localStorage.removeItem(key);
        }
      });
    } catch {
      // ignore
    }

    clearAllPersistentDB();
  };

  const loadSampleTemplate = () => {
    setItems(SAMPLE_ITEMS);
    setBranches(SAMPLE_BRANCHES);
    setRecipes(SAMPLE_RECIPES);
    setCentralBinCards([]);
    setBranchLedgers([]);
    setSchedules([]);
    setReconciliations([]);
    setBranchDailyClosings([]);
    setStaffMealRecipes([]);
    setStaffMembers([]);
    setStaffWeeklySchedules([]);
    setStaffMealExecutions([]);

    saveToPersistentDB('items', SAMPLE_ITEMS);
    saveToPersistentDB('branches', SAMPLE_BRANCHES);
    saveToPersistentDB('recipes', SAMPLE_RECIPES);
  };

  const createManualSnapshot = async (label: string): Promise<BackupSnapshot | null> => {
    return await saveBackupSnapshot(label, {
      version: '4.0.0',
      exportedAt: new Date().toISOString(),
      systemName: 'Ethiopian Enterprise ERP - Master Data Vault',
      items,
      branches,
      centralBinCards,
      branchLedgers,
      recipes,
      schedules,
      reconciliations,
      branchDailyClosings,
      staffMealRecipes,
      staffMembers,
      staffWeeklySchedules,
      staffMealExecutions,
    });
  };

  const loadAllSnapshots = async (): Promise<BackupSnapshot[]> => {
    return await getAllBackupSnapshots();
  };

  const restoreSnapshotById = async (snapshot: BackupSnapshot): Promise<boolean> => {
    try {
      const backup = snapshot.data;
      if (backup.items) setItems(backup.items);
      if (backup.branches) setBranches(backup.branches);
      if (backup.centralBinCards) setCentralBinCards(backup.centralBinCards);
      if (backup.branchLedgers) setBranchLedgers(backup.branchLedgers);
      if (backup.recipes) setRecipes(backup.recipes);
      if (backup.schedules) setSchedules(backup.schedules);
      if (backup.reconciliations) setReconciliations(backup.reconciliations);
      if (backup.branchDailyClosings) setBranchDailyClosings(backup.branchDailyClosings);
      if (backup.staffMealRecipes) setStaffMealRecipes(backup.staffMealRecipes);
      if (backup.staffMembers) setStaffMembers(backup.staffMembers);
      if (backup.staffWeeklySchedules) setStaffWeeklySchedules(backup.staffWeeklySchedules);
      if (backup.staffMealExecutions) setStaffMealExecutions(backup.staffMealExecutions);

      await saveToPersistentDB('items', backup.items || []);
      await saveToPersistentDB('branches', backup.branches || []);
      await saveToPersistentDB('centralBinCards', backup.centralBinCards || []);
      await saveToPersistentDB('branchLedgers', backup.branchLedgers || []);
      await saveToPersistentDB('recipes', backup.recipes || []);
      await saveToPersistentDB('schedules', backup.schedules || []);
      await saveToPersistentDB('reconciliations', backup.reconciliations || []);
      await saveToPersistentDB('branchDailyClosings', backup.branchDailyClosings || []);
      await saveToPersistentDB('staffMealRecipes', backup.staffMealRecipes || []);
      await saveToPersistentDB('staffMembers', backup.staffMembers || []);
      await saveToPersistentDB('staffWeeklySchedules', backup.staffWeeklySchedules || []);
      await saveToPersistentDB('staffMealExecutions', backup.staffMealExecutions || []);
      return true;
    } catch (err) {
      console.error('Failed to restore snapshot:', err);
      return false;
    }
  };

  const deleteSnapshotById = async (id: string): Promise<boolean> => {
    return await deleteBackupSnapshot(id);
  };

  const exportFullBackup = () => {
    downloadDatabaseBackup({
      items,
      branches,
      centralBinCards,
      branchLedgers,
      recipes,
      schedules,
      reconciliations,
      branchDailyClosings,
      staffMealRecipes,
      staffMembers,
      staffWeeklySchedules,
      staffMealExecutions,
    });
  };

  const restoreBackupFromFile = async (file: File): Promise<boolean> => {
    try {
      const backup = await readDatabaseBackupFile(file);
      if (backup.items) setItems(backup.items);
      if (backup.branches) setBranches(backup.branches);
      if (backup.centralBinCards) setCentralBinCards(backup.centralBinCards);
      if (backup.branchLedgers) setBranchLedgers(backup.branchLedgers);
      if (backup.recipes) setRecipes(backup.recipes);
      if (backup.schedules) setSchedules(backup.schedules);
      if (backup.reconciliations) setReconciliations(backup.reconciliations);
      if (backup.branchDailyClosings) setBranchDailyClosings(backup.branchDailyClosings);
      if (backup.staffMealRecipes) setStaffMealRecipes(backup.staffMealRecipes);
      if (backup.staffMembers) setStaffMembers(backup.staffMembers);
      if (backup.staffWeeklySchedules) setStaffWeeklySchedules(backup.staffWeeklySchedules);
      if (backup.staffMealExecutions) setStaffMealExecutions(backup.staffMealExecutions);

      await saveToPersistentDB('items', backup.items || []);
      await saveToPersistentDB('branches', backup.branches || []);
      await saveToPersistentDB('centralBinCards', backup.centralBinCards || []);
      await saveToPersistentDB('branchLedgers', backup.branchLedgers || []);
      await saveToPersistentDB('recipes', backup.recipes || []);
      await saveToPersistentDB('schedules', backup.schedules || []);
      await saveToPersistentDB('reconciliations', backup.reconciliations || []);
      await saveToPersistentDB('branchDailyClosings', backup.branchDailyClosings || []);
      await saveToPersistentDB('staffMealRecipes', backup.staffMealRecipes || []);
      await saveToPersistentDB('staffMembers', backup.staffMembers || []);
      await saveToPersistentDB('staffWeeklySchedules', backup.staffWeeklySchedules || []);
      await saveToPersistentDB('staffMealExecutions', backup.staffMealExecutions || []);
      return true;
    } catch (err) {
      console.error('Failed to restore backup:', err);
      return false;
    }
  };

  const getSyncCode = (): string => {
    return generateSyncCode({
      items,
      branches,
      centralBinCards,
      branchLedgers,
      recipes,
      schedules,
      reconciliations,
      branchDailyClosings,
      staffMealRecipes,
      staffMembers,
      staffWeeklySchedules,
      staffMealExecutions,
    });
  };

  const applySyncCode = async (code: string): Promise<boolean> => {
    try {
      const backup = parseSyncCode(code);
      if (!backup) return false;
      if (backup.items) setItems(backup.items);
      if (backup.branches) setBranches(backup.branches);
      if (backup.centralBinCards) setCentralBinCards(backup.centralBinCards);
      if (backup.branchLedgers) setBranchLedgers(backup.branchLedgers);
      if (backup.recipes) setRecipes(backup.recipes);
      if (backup.schedules) setSchedules(backup.schedules);
      if (backup.reconciliations) setReconciliations(backup.reconciliations);
      if (backup.branchDailyClosings) setBranchDailyClosings(backup.branchDailyClosings);
      if (backup.staffMealRecipes) setStaffMealRecipes(backup.staffMealRecipes);
      if (backup.staffMembers) setStaffMembers(backup.staffMembers);
      if (backup.staffWeeklySchedules) setStaffWeeklySchedules(backup.staffWeeklySchedules);
      if (backup.staffMealExecutions) setStaffMealExecutions(backup.staffMealExecutions);

      await saveToPersistentDB('items', backup.items || []);
      await saveToPersistentDB('branches', backup.branches || []);
      await saveToPersistentDB('centralBinCards', backup.centralBinCards || []);
      await saveToPersistentDB('branchLedgers', backup.branchLedgers || []);
      await saveToPersistentDB('recipes', backup.recipes || []);
      await saveToPersistentDB('schedules', backup.schedules || []);
      await saveToPersistentDB('reconciliations', backup.reconciliations || []);
      await saveToPersistentDB('branchDailyClosings', backup.branchDailyClosings || []);
      await saveToPersistentDB('staffMealRecipes', backup.staffMealRecipes || []);
      await saveToPersistentDB('staffMembers', backup.staffMembers || []);
      await saveToPersistentDB('staffWeeklySchedules', backup.staffWeeklySchedules || []);
      await saveToPersistentDB('staffMealExecutions', backup.staffMealExecutions || []);
      return true;
    } catch (err) {
      console.error('Failed to apply sync code:', err);
      return false;
    }
  };

  return (
    <AppContext.Provider
      value={{
        items,
        branches,
        centralBinCards,
        branchLedgers,
        recipes,
        schedules,
        reconciliations,
        branchDailyClosings,
        staffMealRecipes,
        staffMembers,
        staffWeeklySchedules,
        staffMealExecutions,
        kitchenPrepItems,
        kitchenPrepBatches,
        recordStockIn,
        transferToBranch,
        recordBranchUsage,
        recordBranchThreeWayUsage,
        setBeginningStock,
        closeBranchDailyAccount,
        deleteBranchDailyClosing,
        saveRecipe,
        deleteRecipe,
        duplicateRecipeToBranch,
        saveSchedule,
        deleteSchedule,
        saveKitchenPrepItem,
        deleteKitchenPrepItem,
        recordKitchenPrepProduction,
        deleteKitchenPrepBatch,
        saveStaffMealRecipe,
        deleteStaffMealRecipe,
        saveStaffMember,
        deleteStaffMember,
        saveStaffWeeklySchedule,
        executeStaffMealAndDeduct,
        deleteStaffMealExecution,
        addNewBranch,
        deleteBranch,
        createDefaultThreeBranches,
        addNewItem,
        deleteItem,
        calculateSmartReconciliation,
        commitReconciliationToLedger,
        getBranchStockBalance,
        clearAllDataCompletely,
        loadSampleTemplate,
        exportFullBackup,
        restoreBackupFromFile,
        createManualSnapshot,
        loadAllSnapshots,
        restoreSnapshotById,
        deleteSnapshotById,
        getSyncCode,
        applySyncCode,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
