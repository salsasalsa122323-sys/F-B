import React, { useState } from 'react';
import { LanguageProvider, useLanguage } from './context/LanguageContext';
import { AppProvider, useApp } from './context/AppContext';
import { Navbar, ActiveTab } from './components/layout/Navbar';
import { DashboardView } from './views/DashboardView';
import { CentralStoreView } from './views/CentralStoreView';
import { BinCardView } from './views/BinCardView';
import { BranchLedgersView } from './views/BranchLedgersView';
import { RecipesView } from './views/RecipesView';
import { StaffMealControllingView } from './views/StaffMealControllingView';
import { SmartReconciliationView } from './views/SmartReconciliationView';
import { FBReportView } from './views/FBReportView';
import { PriceTrackingView } from './views/PriceTrackingView';
import { DataVaultView } from './views/DataVaultView';

import { StockInModal } from './components/modals/StockInModal';
import { TransferModal } from './components/modals/TransferModal';
import { BranchUsageModal } from './components/modals/BranchUsageModal';
import { NewBranchModal } from './components/modals/NewBranchModal';
import { NewItemModal } from './components/modals/NewItemModal';
import { DesktopInstallModal } from './components/modals/DesktopInstallModal';
import { OfflineIndicator } from './components/common/OfflineIndicator';
import { formatEthiopianDate, getTodayDateString } from './utils/ethiopianDate';

const AppContent: React.FC = () => {
  const { language, t } = useLanguage();
  const { branches } = useApp();

  const [activeTab, setActiveTab] = useState<ActiveTab>('dashboard');

  // Modals state
  const [stockInModalOpen, setStockInModalOpen] = useState(false);
  const [selectedStockInItem, setSelectedStockInItem] = useState<string | undefined>(undefined);

  const [transferModalOpen, setTransferModalOpen] = useState(false);
  const [selectedTransferItem, setSelectedTransferItem] = useState<string | undefined>(undefined);
  const [selectedTransferBranch, setSelectedTransferBranch] = useState<string | undefined>(undefined);

  const [branchUsageModalOpen, setBranchUsageModalOpen] = useState(false);
  const [usageBranchId, setUsageBranchId] = useState<string>(branches[0]?.id || '');

  const [newBranchModalOpen, setNewBranchModalOpen] = useState(false);
  const [newItemModalOpen, setNewItemModalOpen] = useState(false);
  const [desktopInstallModalOpen, setDesktopInstallModalOpen] = useState(false);

  // Selected item for Bin Card view
  const [binCardSelectedItemId, setBinCardSelectedItemId] = useState<string | undefined>(undefined);

  const handleOpenStockIn = (itemId?: string) => {
    setSelectedStockInItem(itemId);
    setStockInModalOpen(true);
  };

  const handleOpenTransfer = (itemId?: string, branchId?: string) => {
    setSelectedTransferItem(itemId);
    setSelectedTransferBranch(branchId);
    setTransferModalOpen(true);
  };

  const handleOpenBranchUsage = (branchId: string) => {
    setUsageBranchId(branchId);
    setBranchUsageModalOpen(true);
  };

  const handleSelectBinCardItem = (itemId: string) => {
    setBinCardSelectedItemId(itemId);
    setActiveTab('binCard');
  };

  const handleNavigateToReconcile = (branchId: string) => {
    setActiveTab('reconciliation');
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-amber-400 selection:text-slate-950 relative">
      {/* Ambient subtle luxury gold mesh glow */}
      <div className="fixed top-0 left-1/2 -translate-x-1/2 w-full max-w-7xl h-96 bg-gradient-to-b from-amber-500/5 via-amber-500/[0.02] to-transparent pointer-events-none -z-10 blur-3xl"></div>

      {/* Top Navbar */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenStockIn={() => handleOpenStockIn()}
        onOpenTransfer={() => handleOpenTransfer()}
        onOpenDesktopInstall={() => setDesktopInstallModalOpen(true)}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-6 sm:py-8">
        {activeTab === 'dashboard' && (
          <DashboardView
            setActiveTab={setActiveTab}
            onOpenStockIn={() => handleOpenStockIn()}
            onOpenTransfer={() => handleOpenTransfer()}
            onOpenNewBranch={() => setNewBranchModalOpen(true)}
            onOpenNewItem={() => setNewItemModalOpen(true)}
          />
        )}

        {activeTab === 'centralStore' && (
          <CentralStoreView
            onOpenStockIn={handleOpenStockIn}
            onOpenTransfer={handleOpenTransfer}
            onSelectBinCardItem={handleSelectBinCardItem}
            onOpenNewItem={() => setNewItemModalOpen(true)}
          />
        )}

        {activeTab === 'binCard' && (
          <BinCardView
            initialItemId={binCardSelectedItemId}
            onOpenStockIn={handleOpenStockIn}
            onOpenTransfer={handleOpenTransfer}
          />
        )}

        {activeTab === 'branchLedgers' && (
          <BranchLedgersView
            onOpenTransfer={handleOpenTransfer}
            onOpenBranchUsage={handleOpenBranchUsage}
            onOpenNewBranch={() => setNewBranchModalOpen(true)}
          />
        )}

        {activeTab === 'recipes' && <RecipesView />}

        {activeTab === 'staffMeals' && <StaffMealControllingView />}

        {activeTab === 'reconciliation' && (
          <SmartReconciliationView />
        )}

        {activeTab === 'fbReport' && (
          <FBReportView />
        )}

        {activeTab === 'priceTracking' && (
          <PriceTrackingView onOpenStockIn={handleOpenStockIn} />
        )}

        {activeTab === 'dataVault' && (
          <DataVaultView />
        )}
      </main>

      {/* Footer */}
      <footer className="bg-slate-950 border-t border-amber-500/20 py-4 px-6 text-xs text-slate-400 no-print">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <span className="font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-amber-300 to-yellow-400">
              {t.appName}
            </span>
            <span>•</span>
            <span className="text-slate-400">{language === 'am' ? 'የተቀናጀ የስቶር፣ የቅርንጫፍ እና የሪሲፒ ማኔጅመንት' : 'Integrated ERP & Recipe Reconciliation'}</span>
          </div>
          <div className="text-[11px] text-amber-400/80 font-medium">
            🇪🇹 {formatEthiopianDate(getTodayDateString(), language)} | Powered by AI Studio Enterprise
          </div>
        </div>
      </footer>

      {/* Global Modals */}
      <StockInModal
        isOpen={stockInModalOpen}
        onClose={() => setStockInModalOpen(false)}
        preselectedItemId={selectedStockInItem}
      />

      <TransferModal
        isOpen={transferModalOpen}
        onClose={() => setTransferModalOpen(false)}
        preselectedItemId={selectedTransferItem}
        preselectedBranchId={selectedTransferBranch}
      />

      <BranchUsageModal
        isOpen={branchUsageModalOpen}
        onClose={() => setBranchUsageModalOpen(false)}
        branchId={usageBranchId}
      />

      <NewBranchModal
        isOpen={newBranchModalOpen}
        onClose={() => setNewBranchModalOpen(false)}
      />

      <NewItemModal
        isOpen={newItemModalOpen}
        onClose={() => setNewItemModalOpen(false)}
      />

      <DesktopInstallModal
        isOpen={desktopInstallModalOpen}
        onClose={() => setDesktopInstallModalOpen(false)}
      />

      {/* Connectivity & Offline Indicator */}
      <OfflineIndicator />
    </div>
  );
};

export default function App() {
  return (
    <LanguageProvider>
      <AppProvider>
        <AppContent />
      </AppProvider>
    </LanguageProvider>
  );
}
